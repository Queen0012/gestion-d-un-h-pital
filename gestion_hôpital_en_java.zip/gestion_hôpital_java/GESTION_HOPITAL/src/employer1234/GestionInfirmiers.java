package employer1234;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class GestionInfirmiers extends JFrame {

    private JTextField idField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField ageField;
    private JComboBox<String> genreComboBox;
    private JTextField specialiteField;
    private JTextField debutField;
  
    private JButton enregistrerButton,retour;
    private JButton supprimerButton;
    private JButton modifierButton;

    private JTable infirmierTable;

    private Connection connection;
    private Statement statement;

    public GestionInfirmiers() {
        setTitle("gestion des Infirmiers");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        connectToDatabase();
        createTable();
        refreshTableData();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(7, 2));
        formPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        formPanel.add(idField);
        formPanel.add(new JLabel("Nom:"));
        nomField = new JTextField();
        formPanel.add(nomField);
        formPanel.add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        formPanel.add(prenomField);
        formPanel.add(new JLabel("Âge:"));
        ageField = new JTextField();
        formPanel.add(ageField);
        formPanel.add(new JLabel("Genre:"));
        genreComboBox = new JComboBox<>(new String[]{"Féminin", "Masculin"});
        formPanel.add(genreComboBox);
        formPanel.add(new JLabel("Specialite:"));
       specialiteField = new JTextField();
        formPanel.add(specialiteField);
        formPanel.add(new JLabel("Debut:"));
        debutField = new JTextField();
        formPanel.add(debutField);
     

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        enregistrerButton = new JButton("Enregistrer");
        enregistrerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enregistrerAgent();
            }
        });
        buttonPanel.add(enregistrerButton);

        supprimerButton = new JButton("Supprimer");
        supprimerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                supprimerAgent();
            }
        });
        buttonPanel.add(supprimerButton);

        modifierButton = new JButton("Modifier");
        modifierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifierAgent();
            }
        });
        buttonPanel.add(modifierButton);
        

        

        retour = new JButton("retour");
      retour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
           retour();
            	   
            }

			private void retour() {
				// TODO Auto-generated method stub
			    InterfaceUtilisateur iu = new InterfaceUtilisateur();
	               iu.setVisible(true);
			}
        });
        buttonPanel.add(retour);
        
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        infirmierTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(infirmierTable);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

private void connectToDatabase() {
        try {
            String url = "jdbc:mysql://localhost:3306/dbhospitalier";
            String username = "root";
            String password = "";

            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS infirmier (" +
                "id INT PRIMARY KEY," +
                "nom VARCHAR(50)," +
                "prenom VARCHAR(50)," +
                "age INT," +
                "genre VARCHAR(50)," +
                "specialite VARCHAR(100)," +
                "debut VARCHAR(50)" +
               
                ")";

        try {
            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrerAgent() {
        String id = idField.getText();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String genre = (String) genreComboBox.getSelectedItem();
        String specialite =  specialiteField.getText();
        String debut = debutField.getText();
   

        if (id.isEmpty()||nom.isEmpty() ||prenom.isEmpty()||age.isEmpty() ||debut.isEmpty() ||specialite.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }

        String insertQuery = "INSERT INTO infirmier (id, nom, prenom, age, genre,specialite,debut) " +
                "VALUES (" + id + ", '" + nom + "', '" + prenom + "', " + age + ", '" + genre + "', '" + specialite + "','"+debut+"')";

        try {
            statement.executeUpdate(insertQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void supprimerAgent() {
        int selectedRow = infirmierTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = infirmierTable.getValueAt(selectedRow, 0).toString();
        String deleteQuery = "DELETE FROM infirmier WHERE id = " + id;

        try {
            statement.executeUpdate(deleteQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifierAgent() {
        int selectedRow = infirmierTable.getSelectedRow();
       
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = infirmierTable.getValueAt(selectedRow, 0).toString();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String genre = (String) genreComboBox.getSelectedItem();
        String specialite =  specialiteField.getText();
        String debut = debutField.getText();
      

        if (nom.isEmpty() || prenom.isEmpty() || age.isEmpty() || debut.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }
String updateQuery = "UPDATE infirmier SET nom = '" + nom + "', prenom = '" + prenom +
                "', age = " + age + ", genre = '" + genre + "',specialite='"+specialite+"', debut = '" + debut + "' WHERE id = " + id;

        try {
            statement.executeUpdate(updateQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTableData() {
        String selectQuery = "SELECT * FROM infirmier";

        try {
            ResultSet resultSet = statement.executeQuery(selectQuery);
            infirmierTable.setModel(buildTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        nomField.setText("");
        prenomField.setText("");
        ageField.setText("");
        genreComboBox.setSelectedIndex(0);

        specialiteField.setText("");
        debutField.setText("");
       
    }

    private static DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        // Table data
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                GestionInfirmiers a = new GestionInfirmiers();
                a.setExtendedState(MAXIMIZED_BOTH);
                a.setVisible(true);
            }
        });
    }
}
