package employer1234;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class diagnostics extends JFrame {

    private JTextField idField;
    private JComboBox<String> examenComboBox;
    private JTextField resultatField;
  
    
    private JButton enregistrerButton;
    private JButton supprimerButton;
    private JButton modifierButton,retour;
    private JTable examenTable;

    private Connection connection;
    private Statement statement;

    public diagnostics() {
        setTitle("Diagnostics");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        connectToDatabase();
        createTable();
        refreshTableData();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(3, 2));
        formPanel.add(new JLabel("ID_patient:"));
        idField = new JTextField();
        formPanel.add(idField);
        formPanel.add(new JLabel("Nom de l'examen:"));
        examenComboBox = new JComboBox<>(new String[]{"Goutte épaisse","GE","NFS", "Examen de selles", "Examen d'urine", "Radiographie", "Echographie", "Widal test", "VIH test", "Test de CRP", "Glycémie", "Examen de Ca, Mg, K", "Félix test"});
        formPanel.add(examenComboBox);
        formPanel.add(new JLabel("Resultat:"));
        resultatField = new JTextField();
        formPanel.add(resultatField);
     

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        enregistrerButton = new JButton("Enregistrer");
        enregistrerButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                enregistrer();
            }
        });
        buttonPanel.add(enregistrerButton);

        supprimerButton = new JButton("Supprimer");
        supprimerButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                supprimer();
            }
        });
        buttonPanel.add(supprimerButton);

        modifierButton = new JButton("Modifier");
        modifierButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                modifier();
            }
        });
        buttonPanel.add(modifierButton);
        
        retour = new JButton("back");
        retour.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
               Patient_maladie pm= new Patient_maladie();
               pm.setVisible(true);
            }
        });
        buttonPanel.add(retour);
        
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

       examenTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(examenTable);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

private void connectToDatabase() {
        try {
            String url = "jdbc:mysql://localhost:3306/dbhospitalier";
            String username = "root";
            String password = "";

            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS examen (" +
                "id INT PRIMARY KEY," +
                "examen VARCHAR(50)," +
                "resultat VARCHAR(50)" +
              
               
                ")";

        try {
            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
        String id = idField.getText();;
        String examen = (String) examenComboBox.getSelectedItem();
        String resultat = resultatField.getText();
     

        if (id.isEmpty() ||examen.isEmpty() ||resultat.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }

        String insertQuery = "INSERT INTO examen (id, examen,resultat) " +
                "VALUES (" + id + ", '" + examen + "', '" + resultat + "')";

        try {
            statement.executeUpdate(insertQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void supprimer() {
        int selectedRow = examenTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = examenTable.getValueAt(selectedRow, 0).toString();
        String deleteQuery = "DELETE FROM examen WHERE id = " + id;

        try {
            statement.executeUpdate(deleteQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifier() {
        int selectedRow = examenTable.getSelectedRow();
       
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = examenTable.getValueAt(selectedRow, 0).toString();
        String examen = (String) examenComboBox.getSelectedItem();
        String resultat = resultatField.getText();
      

        if (examen.isEmpty() || resultat.isEmpty() ) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }
String updateQuery = "UPDATE examen SET examen = '" + examen + "', resultat = '" + resultat +
                "' WHERE id = " + id;

        try {
            statement.executeUpdate(updateQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTableData() {
        String selectQuery = "SELECT * FROM examen";

        try {
            ResultSet resultSet = statement.executeQuery(selectQuery);
            examenTable.setModel(buildTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        examenComboBox.setSelectedIndex(0);
        resultatField.setText("");
    }

    private static DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        // Table data
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
        
            public void run() {
                diagnostics ag = new diagnostics();
                ag.setExtendedState(MAXIMIZED_BOTH);
                ag.setVisible(true);
            }
        });
    }
}
