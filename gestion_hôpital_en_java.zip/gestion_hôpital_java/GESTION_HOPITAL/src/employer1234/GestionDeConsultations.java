package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class GestionDeConsultations extends JFrame implements ActionListener {
    private JTextField idField, symptomesField,temperatureField, dateField;
    private JComboBox<String> patientComboBox, medecinComboBox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable consultationTable;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public GestionDeConsultations() {
        // Initialisation de la fenêtre
        setTitle("Gestion des consultations");
      
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
        patientComboBox = new JComboBox<>();
        medecinComboBox = new JComboBox<>();
        symptomesField = new JTextField(10);
        temperatureField = new JTextField(10);
        dateField = new JTextField(10);

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
       retour = new JButton("retour");

        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
       retour.addActionListener(this);

        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ID"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Patient"));
        inputPanel.add(patientComboBox);
        inputPanel.add(new JLabel("Médecin"));
        inputPanel.add(medecinComboBox);
        inputPanel.add(new JLabel("Symptômes"));
        inputPanel.add(symptomesField);
        inputPanel.add(new JLabel("Température"));
        inputPanel.add(temperatureField);
        inputPanel.add(new JLabel("Date"));
        inputPanel.add(dateField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);
        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
        loadPatients();
        loadMedecins();

        // Chargement des consultations dans le tableau
        loadConsultations();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadPatients() {
        try {
            String query = "SELECT nom FROM patient";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom = resultSet.getString("nom");
                patientComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadMedecins() {
        try {
            String query = "SELECT nom FROM medecin";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom =resultSet.getString("nom");
                medecinComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadConsultations() {
        try {
            String query = "SELECT * FROM cons";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID");
            tableModel.addColumn("Patient");
            tableModel.addColumn("Médecin");
            tableModel.addColumn("Symptômes");
            tableModel.addColumn("Température");
            tableModel.addColumn("Date");

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String patient = resultSet.getString("patient");
                String medecin = resultSet.getString("medecin");
                String symptomes = resultSet.getString("symptomes");
                String temperature = resultSet.getString("temperature");
                String date = resultSet.getString("date");

                tableModel.addRow(new Object[]{id, patient, medecin, symptomes,temperature, date});
            }

            // Création du tableau avec le modèle de tableau
            consultationTable = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(consultationTable);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrerConsultation() {
        String id = idField.getText();
        String patient = (String) patientComboBox.getSelectedItem();
        String medecin = (String) medecinComboBox.getSelectedItem();
        String symptomes = symptomesField.getText();
        String temperature = temperatureField.getText();
        String date = dateField.getText();

        if (!id.isEmpty() && !patient.isEmpty() && !medecin.isEmpty()
                && !symptomes.isEmpty()  && !temperature.isEmpty() && !date.isEmpty()) {
            try {
                String query = "INSERT INTO cons (id, patient, medecin, symptomes,temperature, date) " +
                        "VALUES (" + id + ", '" + patient + "', '" + medecin + "', '" + symptomes + "','"+temperature+"', '" + date + "')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id, patient, medecin, symptomes,temperature, date});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimerConsultation() {
        int selectedRow = consultationTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) consultationTable.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM cons WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une consultation à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifierConsultation() {
        int selectedRow = consultationTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) consultationTable.getValueAt(selectedRow, 0);
            String patient = (String) patientComboBox.getSelectedItem();
            String medecin = (String) medecinComboBox.getSelectedItem();
            String symptomes = symptomesField.getText();
            String temperature = temperatureField.getText();
            String date = dateField.getText();

            if ( !patient.isEmpty()&& !medecin.isEmpty()&&!symptomes.isEmpty() && !temperature.isEmpty()&& !date.isEmpty()) {
                try {
                    String query = "UPDATE cons SET patient = '" + patient + "', medecin = '" + medecin + "', symptomes = '"
                            + symptomes + "',temperature = '"+temperature+"', date = '" + date + "' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                    consultationTable.setValueAt(patient, selectedRow, 1);
                    consultationTable.setValueAt(medecin, selectedRow, 2);
                    consultationTable.setValueAt(symptomes, selectedRow, 3);
                    consultationTable.setValueAt(temperature, selectedRow, 4);
                    consultationTable.setValueAt(date, selectedRow, 5);
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une consultation à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        patientComboBox.setSelectedIndex(0);
        medecinComboBox.setSelectedIndex(0);
        symptomesField.setText("");
       temperatureField.setText("");
        dateField.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrerConsultation();
        } else if (e.getSource() == supprimerButton) {
            supprimerConsultation();
        } else if (e.getSource() == modifierButton) {
            modifierConsultation();
        }else if (e.getSource() == retour) {
            retour();
        }
    }

    private void retour() {
		// TODO Auto-generated method stub
    	generalConsultations g = new generalConsultations();
    	g.setVisible(true);
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	GestionDeConsultations ab =  new GestionDeConsultations();
            	ab.setExtendedState(MAXIMIZED_BOTH);
            	ab.setVisible(true);
            }
        });
    }
}