package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class urgence2 extends JFrame implements ActionListener {
    private JTextField idField,heureField,traitementField,dateField;
    private JComboBox<String> infirmierComboBox, medecinComboBox,typecombox,niveaucombox,statutcombox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable Table;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public urgence2() {
        // Initialisation de la fenêtre
        setTitle("Gestion des urgences");
   
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
      typecombox = new JComboBox<>(new String[]{"Urgence médicale", "Urgences chirurgicale", "Accident"});
      niveaucombox = new JComboBox<>(new String[]{"Mineur", "Modéré", "Grave"});
        dateField = new JTextField(10);
       heureField = new JTextField(10);
       traitementField = new JTextField(10);
       medecinComboBox = new JComboBox<>();
        infirmierComboBox = new JComboBox<>();

        statutcombox = new JComboBox<>(new String[]{"En attente de traitement", "Sous observation", "En cours de traitement", "Stable", "Nécessite une intervention urgente"});
  

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
        retour = new JButton("retour");
        
        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
        retour.addActionListener(this);

        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(9, 2));
        inputPanel.add(new JLabel("ID"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Type d'urgence"));
        inputPanel.add(typecombox);
        inputPanel.add(new JLabel("Niveau de gravité"));
        inputPanel.add(niveaucombox);   
        inputPanel.add(new JLabel("Date"));
        inputPanel.add(dateField);
        inputPanel.add(new JLabel("Heure"));
        inputPanel.add(heureField);
        inputPanel.add(new JLabel("Traitement initial"));
        inputPanel.add(traitementField);
        inputPanel.add(new JLabel("Médecin"));
        inputPanel.add(medecinComboBox);
        inputPanel.add(new JLabel("Infirmier"));
        inputPanel.add(infirmierComboBox);
        inputPanel.add(new JLabel("Statut du patient"));
        inputPanel.add(statutcombox);
        

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);

        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
        loadinfirmiers();
        loadMedecins();

        loadurg();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadinfirmiers() {
        try {
            String query = "SELECT nom FROM infirmier";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom = resultSet.getString("nom");
                infirmierComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadMedecins() {
        try {
            String query = "SELECT nom FROM medecin";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom =resultSet.getString("nom");
                medecinComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadurg() {
        try {
            String query = "SELECT * FROM urg";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID");
            tableModel.addColumn("Type d'urgence");
            tableModel.addColumn("Niveau de gravité");
            tableModel.addColumn("Date");
            tableModel.addColumn("Heure");
            tableModel.addColumn("Traitement initial");
            tableModel.addColumn("Médecin");
            tableModel.addColumn("Infirmier");
            tableModel.addColumn("Statut du patient");
        

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String type = resultSet.getString("type");
                String niveau = resultSet.getString("niveau");
                String date = resultSet.getString("date");
                String heure = resultSet.getString("heure");
                String traitement = resultSet.getString("traitement");
                String infirmier = resultSet.getString("medecin");
                String medecin = resultSet.getString("infirmier");
              
                String statut = resultSet.getString("statut");
         
                
                tableModel.addRow(new Object[]{id,type,niveau,date,heure,traitement, medecin,infirmier,statut});
            }

            // Création du tableau avec le modèle de tableau
          Table = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(Table);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
    	   String id = idField.getText();
    	      String type = (String) typecombox.getSelectedItem();
    	        String niveau = (String) niveaucombox.getSelectedItem();
        String date = dateField.getText();
        String heure = heureField.getText();
        String traitement =traitementField.getText();
        String medecin = (String) medecinComboBox.getSelectedItem();

        String infirmier = (String) infirmierComboBox.getSelectedItem();
        String statut = (String) statutcombox.getSelectedItem();
        
      


        if (!id.isEmpty() && !date.isEmpty() &&!heure.isEmpty() && !traitement.isEmpty() ) {
            try {
                String query = "INSERT INTO urg (id,type,niveau,date,heure,traitement,medecin,infirmier,statut) " +
                        "VALUES (" + id + ", '" +type + "','"+niveau+"','"+heure+"','"+date+"','"+traitement+"','"+medecin+"', '" + infirmier + "', '" + statut + "')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id,type,niveau,heure,date,traitement, medecin,infirmier,statut});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimer() {
        int selectedRow = Table.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) Table.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM urg WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifier() {
        int selectedRow = Table.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) Table.getValueAt(selectedRow, 0);
  	      String type = (String) typecombox.getSelectedItem();
	        String niveau = (String) niveaucombox.getSelectedItem();
  String date = dateField.getText();
  String heure = heureField.getText();
  String traitement =traitementField.getText();
  String medecin = (String) medecinComboBox.getSelectedItem();

  String infirmier = (String) infirmierComboBox.getSelectedItem();
  String statut = (String) statutcombox.getSelectedItem();;

            if (!date.isEmpty() &&!heure.isEmpty() && !traitement.isEmpty()) {
                 try {
                    String query = "UPDATE urg SET type = '" + type + "',niveau= '"+niveau+"',date= '"+date+"',heure='"+heure+"',traitement='"+traitement+"' , medecin = '" + medecin + "',statut = '"+statut+"' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                    Table.setValueAt(type, selectedRow, 1);
                    Table.setValueAt(niveau, selectedRow, 2);
    Table.setValueAt(date, selectedRow, 3);
         Table.setValueAt(heure, selectedRow, 4);
        Table.setValueAt(traitement, selectedRow, 5);
                 Table.setValueAt(medecin, selectedRow, 6);
                   Table.setValueAt(infirmier, selectedRow, 7);
                  Table.setValueAt(statut, selectedRow, 8);
                 
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        typecombox.setSelectedIndex(0);
       niveaucombox.setSelectedIndex(0);
        dateField.setText("");
        heureField.setText("");
     traitementField.setText("");
        medecinComboBox.setSelectedIndex(0);
       infirmierComboBox.setSelectedIndex(0);
     statutcombox.setSelectedIndex(0);
 
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrer();
        } else if (e.getSource() == supprimerButton) {
            supprimer();
        } else if (e.getSource() == modifierButton) {
            modifier();
        }else if (e.getSource() == retour) {
               retour();
            }
        }
    

    private void retour() {
		// TODO Auto-generated method stub
    	InterfaceUtilisateur iu = new InterfaceUtilisateur();
    	iu.setVisible(true);
    	
		
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	urgence2 dd=   new urgence2();
            	dd.setExtendedState(MAXIMIZED_BOTH);
            	dd.setVisible(true);
            }
        });
    }
}