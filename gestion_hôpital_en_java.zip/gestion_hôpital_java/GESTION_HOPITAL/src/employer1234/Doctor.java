package employer1234;

import java.util.ArrayList;
import java.util.List;

public class Doctor {

	private String id;
	private String nom;
	private String prenom;
	private String specialite;
	private String adresse;
	private String heureSemaine;
	private String DateDuCommencement;
	private String DureeExperience;
	private double salaire;
	
	
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	
	public Doctor( String nom, String prenom, String specialite, String adresse, String heureSemaine,
			String dateDuCommencement, String dureeExperience) {
	
		this.nom=nom;
		this.prenom=prenom;
		this.specialite=specialite;
		this.adresse = adresse;
		this.heureSemaine=heureSemaine;
		this.DateDuCommencement=DateDuCommencement;
		this.DureeExperience=DureeExperience;
		this.salaire=salaire;
		
		
		
		// TODO Auto-generated constructor stub
	}
	public String getId() {
		return id;
		
	}
	
	public void setId(String id) {
		this.id=id;
	}
	
	public String getNom() {
		return nom;
		
	}
	
	public void setNom(String nom) {
		this.nom=nom;
	}
	
	public String getprenom() {
		return prenom;
		
	}
	
	public void setprenom(String prenom) {
		this.prenom=prenom;
	}
	
	public String getSpecialite() {
		return specialite;
		
	}
	
	public void setSpecialite(String specialite) {
		this.specialite=specialite;
	

	}
	public String getadresse() {
		return adresse;
		
	}
	
	public void setadresse(String adresse) {
		this.adresse=adresse;
	}
	public String getheureSemaine() {
		return heureSemaine;
		
	}
	
	public void setheureSemaine(String heureSemaine) {
		this.heureSemaine=heureSemaine;
	}
	
	public String getDateDuCommencement() {
		return DateDuCommencement;
		
	}
	
	public void setDateDuCommencement(String DateDuCommencement) {
		this.DateDuCommencement=DateDuCommencement;
	}
	
	public String getDureeExperience() {
		return DureeExperience;
		
	}
	
	public void setDureeExperience(String DureeExperience) {
		this.DureeExperience=DureeExperience;
	}
	
	public double getSalaire() {
		return salaire;
	}
	
	
	
	public void setSalaire(double salaire) {
		// TODO Auto-generated method stub
		this.salaire=salaire;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}

