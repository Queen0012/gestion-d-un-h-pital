package employer1234;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class operation extends JFrame {

    public operation() {
        setTitle("Gestion des opérations");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Création des boutons à gauche
        JPanel buttonPanel = new JPanel(new GridLayout(2,1));
        JPanel buttonPanel1 = new JPanel();

        JButton button1 = new JButton("reservation");
        JButton button2 = new JButton("equipements");
        
        JButton button4 = new JButton("back");
        buttonPanel.add(button1);
        buttonPanel.add(button2);
     
        buttonPanel1.add(button4);

        // Ajout des boutons à gauche
        mainPanel.add(buttonPanel, BorderLayout.EAST);
        mainPanel.add(buttonPanel1, BorderLayout.SOUTH);
        
        ImageIcon image = new ImageIcon("images/equip.jpg");
        JLabel labelImage = new JLabel(image);
        labelImage.setHorizontalAlignment(JLabel.CENTER);
        mainPanel.add(labelImage, BorderLayout.CENTER);

        // Action lorsqu'on clique sur le bouton 1
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	Reservation re = new Reservation();
            	re.setExtendedState(MAXIMIZED_BOTH);
            	re.setVisible(true);
        	
            }
        });
        
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	equipement ep = new equipement();
            	ep.setExtendedState(MAXIMIZED_BOTH);
            	ep.setVisible(true);
            
            }
        });
        
    
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                 inter op = new inter();
        		op.setVisible(true);
            
            }
        });

        // Ajout du panneau principal à la fenêtre
        add(mainPanel);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new operation().setVisible(true);
            }
        });
    }
}