package employer1234;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.util.HashSet;
import java.util.Set;

public class Admin extends JFrame {

    private JTextField idField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField ageField;
    private JComboBox<String> posteComboBox;
    private JTextField adresseField;
    private JTextField emailField;
    private JTextField telephoneField;
    private JButton enregistrerButton,retour;
    private JButton supprimerButton;
    private JButton modifierButton;
    private JTable doctorTable;

    private Connection connection;
    private Statement statement;

    public Admin() {
        setTitle("Gestion des administrateurs");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        connectToDatabase();
        createTable();
        refreshTableData();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(8, 2));
        formPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        formPanel.add(idField);
        formPanel.add(new JLabel("Nom:"));
        nomField = new JTextField();
        formPanel.add(nomField);
        formPanel.add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        formPanel.add(prenomField);
        formPanel.add(new JLabel("Âge:"));
        ageField = new JTextField();
        formPanel.add(ageField);
        formPanel.add(new JLabel("Poste:"));
        posteComboBox = new JComboBox<>(new String[]{"Directeur général", "Directeur administratif et financier", "Directeur de gestion des ressources humaines", "Directeur des opérations", "Directeur médical", "Directeur de services infirmiers", "Directeur des technologies des informations", "Directeur de la qualité et de la gestion des risques", "Directeur des relations publiques et de la communication", "Directeur du développement et des relations avec les donateurs"});
        formPanel.add(posteComboBox);
        formPanel.add(new JLabel("adresse"));
        adresseField = new JTextField();
        formPanel.add(adresseField);
        formPanel.add(new JLabel("email"));
        emailField = new JTextField();
        formPanel.add(emailField);
        formPanel.add(new JLabel("telephone:"));
        telephoneField = new JTextField();
        formPanel.add(telephoneField);
      

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        enregistrerButton = new JButton("Enregistrer");
        enregistrerButton.addActionListener(new ActionListener() {
           
            public void actionPerformed(ActionEvent e) {
                enregistrerAgent();
            }
        });
        buttonPanel.add(enregistrerButton);

        supprimerButton = new JButton("Supprimer");
        supprimerButton.addActionListener(new ActionListener() {
         
            public void actionPerformed(ActionEvent e) {
                supprimerAgent();
            }
        });
        buttonPanel.add(supprimerButton);

        modifierButton = new JButton("Modifier");
        modifierButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                modifierAgent();
            }
        });
        buttonPanel.add(modifierButton);
        retour = new JButton("retour");
        retour.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                InterfaceUtilisateur iu = new InterfaceUtilisateur();
                iu.setVisible(true);
            }
        });

        buttonPanel.add(retour);
  
        
        

        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

      doctorTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(doctorTable);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

private void connectToDatabase() {
        try {
            // Remplacez les informations de connexion par celles de votre base de données
            String url = "jdbc:mysql://localhost:3306/dbhospitalier";
            String username = "root";
            String password = "";

            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS admin(" +
                "id INT PRIMARY KEY," +
                "nom VARCHAR(50)," +
                "prenom VARCHAR(50)," +
                "age INT," +
                "poste VARCHAR(50)," +
                "adresse VARCHAR(50)," +
                "email VARCHAR(50)," +
                "telephone VARCHAR(50)" +
                
                ")";

        try {
            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrerAgent() {
        String id = idField.getText();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String poste = (String) posteComboBox.getSelectedItem();
        String adresse = adresseField.getText();
        String email = emailField.getText();
        String telephone = telephoneField.getText();
       

        if (id.isEmpty() ||nom.isEmpty() ||prenom.isEmpty()|| age.isEmpty() ||adresse.isEmpty() ||
                email.isEmpty() || telephone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }

        String insertQuery = "INSERT INTO admin (id, nom, prenom, age,poste, adresse,email,telephone) " +
                "VALUES (" + id + ", '" + nom + "', '" + prenom + "', " + age + ", '" + poste + "', '"+adresse+"','"+ email + "', '" + telephone+ "')";
             
        if (isPosteOccupe(poste)) {
            JOptionPane.showMessageDialog(this, "Ce poste est déjà occupé", "Erreur", JOptionPane.ERROR_MESSAGE);
            return;
        }
        try {
            statement.executeUpdate(insertQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private boolean isPosteOccupe(String poste) {
        try {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT poste FROM admin");

            Set<String> postesOccupes = new HashSet<>();
            while (resultSet.next()) {
                postesOccupes.add(resultSet.getString("poste"));
            }

            statement.close();

            return postesOccupes.contains(poste);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return false;
    }

	private void supprimerAgent() {
        int selectedRow = doctorTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = doctorTable.getValueAt(selectedRow, 0).toString();
        String deleteQuery = "DELETE FROM admin WHERE id = " + id;

        try {
            statement.executeUpdate(deleteQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifierAgent() {
        int selectedRow = doctorTable.getSelectedRow();
       
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = doctorTable.getValueAt(selectedRow, 0).toString();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String poste = (String) posteComboBox.getSelectedItem();
        String adresse = adresseField.getText();
        String email = emailField.getText();
        String telephone = telephoneField.getText();


        if (nom.isEmpty() || prenom.isEmpty() || age.isEmpty() || adresse.isEmpty() ||
                email.isEmpty() || telephone.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }
String updateQuery = "UPDATE admin SET nom = '" + nom + "', prenom = '" + prenom +
                "', age = " + age + ", poste = '" + poste + "',adresse='"+adresse+"', email = '" + email + "', telephone = '" +telephone +
                "' WHERE id = " + id;

        try {
            statement.executeUpdate(updateQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTableData() {
        String selectQuery = "SELECT * FROM admin";

        try {
            ResultSet resultSet = statement.executeQuery(selectQuery);
            doctorTable.setModel(buildTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        nomField.setText("");
        prenomField.setText("");
        ageField.setText("");
       posteComboBox.setSelectedIndex(0);
        adresseField.setText("");
        emailField.setText("");
        telephoneField.setText("");
       ;
    }

    private static DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        // Table data
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
          
            public void run() {
                Admin agentEntretienGUI = new Admin();
                agentEntretienGUI.setVisible(true);
            }
        });
    }
}
