package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class vaccination1 extends JFrame implements ActionListener {
    private JTextField idField,dureeField;
    private JComboBox<String> patientComboBox, medecinComboBox,vaccincombox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable vaccinTable;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public vaccination1() {
        // Initialisation de la fenêtre
        setTitle("Gestion de la vaccination: cas des enfants");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
        patientComboBox = new JComboBox<>();
        medecinComboBox = new JComboBox<>();
        vaccincombox = new JComboBox<>(new String[]{
                "Vaccin contre la fièvre jaune",
                "Vaccin contre la diphtérie, le tétanos et la coqueluche (DTC)",
                "Vaccin contre la poliomyélite (VPO)",
                "Vaccin contre la rougeole, les oreillons et la rubéole (ROR)",
                "Vaccin contre l'hépatite B",
                "Vaccin contre la varicelle",
                "Vaccin contre la grippe saisonnière",
                "Vaccin contre le rotavirus",
                "Vaccin contre le pneumocoque",
                "Vaccin contre le méningocoque",
                "Vaccin contre le papillomavirus humain (HPV)"
        });
        dureeField = new JTextField(10);

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
        retour = new JButton("retour");

        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
        retour.addActionListener(this);
        
        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        inputPanel.add(new JLabel("ID"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Patient"));
        inputPanel.add(patientComboBox);
        inputPanel.add(new JLabel("Médecin"));
        inputPanel.add(medecinComboBox);
        inputPanel.add(new JLabel("Vaccin"));
        inputPanel.add(vaccincombox);
        inputPanel.add(new JLabel("Durée"));
        inputPanel.add(dureeField);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);

        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
        loadPatients();
        loadMedecins();

        // Chargement des consultations dans le tableau
        loadvaccin();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadPatients() {
        try {
            String query = "SELECT nom FROM patient";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom = resultSet.getString("nom");
                patientComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadMedecins() {
        try {
            String query = "SELECT nom FROM medecin";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom =resultSet.getString("nom");
                medecinComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadvaccin() {
        try {
            String query = "SELECT * FROM vaccin";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID");
            tableModel.addColumn("Patient");
            tableModel.addColumn("Médecin");
            tableModel.addColumn("Vaccin");
            tableModel.addColumn("Durée");

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String patient = resultSet.getString("patient");
                String medecin = resultSet.getString("medecin");
                String vaccin = resultSet.getString("vaccin");
                String duree = resultSet.getString("duree");

                tableModel.addRow(new Object[]{id, patient, medecin, vaccin, duree});
            }

            // Création du tableau avec le modèle de tableau
           vaccinTable = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(vaccinTable);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
        String id = idField.getText();
        String patient = (String) patientComboBox.getSelectedItem();
        String medecin = (String) medecinComboBox.getSelectedItem();
        String vaccin = (String) vaccincombox.getSelectedItem();
        String duree = dureeField.getText();

        if (!id.isEmpty() && !patient.isEmpty() && !medecin.isEmpty()
                && !vaccin.isEmpty() && !duree.isEmpty()) {
            try {
                String query = "INSERT INTO vaccin (id, patient, medecin, vaccin, duree) " +
                        "VALUES (" + id + ", '" + patient + "', '" + medecin + "', '" + vaccin + "', '" + duree + "')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id, patient, medecin, vaccin, duree});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimer() {
        int selectedRow = vaccinTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) vaccinTable.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM vaccin WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifier() {
        int selectedRow = vaccinTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) vaccinTable.getValueAt(selectedRow, 0);
            String patient = (String) patientComboBox.getSelectedItem();
            String medecin = (String) medecinComboBox.getSelectedItem();
            String vaccin = (String) vaccincombox.getSelectedItem();
            String duree = dureeField.getText();

            if (!duree.isEmpty()) {
                try {
                    String query = "UPDATE vaccin SET patient = '" + patient + "', medecin = '" + medecin + "', vaccin = '"
                            + vaccin + "', duree = '" + duree + "' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                    vaccinTable.setValueAt(patient, selectedRow, 1);
                    vaccinTable.setValueAt(medecin, selectedRow, 2);
                    vaccinTable.setValueAt(vaccin, selectedRow, 3);
                    vaccinTable.setValueAt(duree, selectedRow, 4);
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        patientComboBox.setSelectedIndex(0);
        medecinComboBox.setSelectedIndex(0);
        vaccincombox.setSelectedIndex(0);
        dureeField.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrer();
        } else if (e.getSource() == supprimerButton) {
            supprimer();
        } else if (e.getSource() == modifierButton) {
            modifier();
        } else if (e.getSource() == retour) {
            retour();
        }
    }

    private void retour() {
		// TODO Auto-generated method stub
    	GestionVaccination ed = new GestionVaccination();
    	ed.setVisible(true);
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	vaccination1 v=   new vaccination1();
            	v.setExtendedState(MAXIMIZED_BOTH);
            }
        });
    }
}