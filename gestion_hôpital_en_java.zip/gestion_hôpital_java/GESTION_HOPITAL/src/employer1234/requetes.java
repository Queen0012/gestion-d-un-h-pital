package employer1234;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class requetes extends JFrame {
	Statement st;
	Connectage con=new Connectage();
	ResultSet rst;
	JTable table,table2,table3;
	JScrollPane scroll,scroll2,scroll3;
	JButton retour;
	JLabel lbtitre1;
	public requetes(){
		this.setTitle("bilan des maladies");
		this.setSize(900,640);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		
		lbtitre1=new JLabel("Nombre de malades par type de maladies par mois");
		lbtitre1.setBounds(50,10,800,30);
		lbtitre1.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbtitre1);
		
		retour=new JButton("retour");
		retour.setBounds(400,530,100,25);
		retour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev){
				Patient_maladie g = new Patient_maladie();
				g.setVisible(true);
			
			}
		});
		pn.add(retour);
		//liste nombres de malades par type de maladies
		DefaultTableModel df=new  DefaultTableModel();
		  init();
		  pn.add(scroll);
		 df.addColumn("Maladie");
		 df.addColumn("Nombre patients");
		 df.addColumn("Mois");
		 df.addColumn("Année");
		 
	
		 table.setModel(df);
		 String req="select nom_mal,count(id) as nombre,mois,annee from tb_resultat group by mois,annee,nom_mal ";
		 try{
			 st=con.laconnexion().createStatement();
			 rst=st.executeQuery(req);
			 while(rst.next()){
				 df.addRow(new Object[]{
rst.getString("nom_mal"),rst.getString("nombre"),rst.getString("mois"),rst.getString("annee")


						 });
				 
			 }
			 
				 
			 }
			 
		 catch(SQLException ex){
		    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
		    }
	}
	private void init(){
		table=new JTable();
		scroll=new JScrollPane();
		scroll.setBounds(10,50,870,450);
		scroll.setViewportView(table);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		requetes rq=new requetes();
		rq.setVisible(true);
		
		

	}

}
