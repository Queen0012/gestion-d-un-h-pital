package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Naissance extends JFrame implements ActionListener {
    private JTextField idField,nomField,prenomField,mereField,pereField,lieuField,dateField,heureField,sageField;
    private JComboBox<String> infirmierComboBox, medecinComboBox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable naissanceTable;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Naissance() {
        // Initialisation de la fenêtre
        setTitle("Gestion des Naissances");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
        nomField = new JTextField(10);
        prenomField = new JTextField(10);
        mereField = new JTextField(10);
       pereField = new JTextField(10);
        infirmierComboBox = new JComboBox<>();
        medecinComboBox = new JComboBox<>();
       lieuField = new JTextField(10);
        dateField = new JTextField(10);
        heureField = new JTextField(10);
        sageField = new JTextField(10);
        

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
        retour = new JButton("retour");

        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
       retour.addActionListener(this);

        
        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(11, 2));
        inputPanel.add(new JLabel("ID"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Nom"));
        inputPanel.add(nomField);
        inputPanel.add(new JLabel("Prenom"));
        inputPanel.add(prenomField);   
        inputPanel.add(new JLabel("Mère"));
        inputPanel.add(mereField);
        inputPanel.add(new JLabel("Père"));
        inputPanel.add(pereField);
        inputPanel.add(new JLabel("Infirmier"));
        inputPanel.add(infirmierComboBox);
        inputPanel.add(new JLabel("Médecin"));
        inputPanel.add(medecinComboBox);
        inputPanel.add(new JLabel("lieu(pays-ville)"));
        inputPanel.add(lieuField);
        inputPanel.add(new JLabel("date"));
        inputPanel.add(dateField);
        inputPanel.add(new JLabel("heure"));
        inputPanel.add(heureField);
        inputPanel.add(new JLabel("Sage(s) femme(s)"));
        inputPanel.add(sageField);
        

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);

        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
        loadinfirmiers();
        loadMedecins();

        loadnaissance();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadinfirmiers() {
        try {
            String query = "SELECT nom FROM infirmier";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom = resultSet.getString("nom");
                infirmierComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadMedecins() {
        try {
            String query = "SELECT nom FROM medecin";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom =resultSet.getString("nom");
                medecinComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadnaissance() {
        try {
            String query = "SELECT * FROM naissance";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID");
            tableModel.addColumn("Nom");
            tableModel.addColumn("Prenom");
            tableModel.addColumn("mère");
            tableModel.addColumn("Père");
            tableModel.addColumn("Infirmier");
            tableModel.addColumn("Médecin");
            tableModel.addColumn("Lieu");
            tableModel.addColumn("Date");
            tableModel.addColumn("Heure");
            tableModel.addColumn("Sage(s) femmes(s)");

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String nom = resultSet.getString("nom");
                String prenom = resultSet.getString("prenom");
                String mere = resultSet.getString("mere");
                String pere = resultSet.getString("pere");
                String infirmier = resultSet.getString("infirmier");
                String medecin = resultSet.getString("medecin");
                String lieu = resultSet.getString("lieu");
                String date = resultSet.getString("date");
                String heure = resultSet.getString("heure");
                String sage = resultSet.getString("sage");
                
                tableModel.addRow(new Object[]{id,nom,prenom,mere,pere,infirmier, medecin,lieu, date,heure,sage});
            }

            // Création du tableau avec le modèle de tableau
            naissanceTable = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(naissanceTable);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
    	   String id = idField.getText();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String mere = mereField.getText();
        String pere = pereField.getText();
        String infirmier = (String) infirmierComboBox.getSelectedItem();
        String medecin = (String) medecinComboBox.getSelectedItem();
        String lieu = lieuField.getText();
        String date = dateField.getText();
        String heure = heureField.getText();
        String sage = sageField.getText();


        if (!id.isEmpty() && !nom.isEmpty() &&!prenom.isEmpty() && !mere.isEmpty() &&  !pere.isEmpty()&&
        		!infirmier.isEmpty() &&!medecin.isEmpty() && !lieu.isEmpty() && !date.isEmpty() &&!heure.isEmpty() &&!sage.isEmpty()) {
            try {
                String query = "INSERT INTO naissance (id,nom,prenom,mere,pere,infirmier, medecin,lieu, date,heure,sage) " +
                        "VALUES (" + id + ", '" + nom + "','"+prenom+"','"+mere+"','"+pere+"','"+infirmier+"', '" + medecin + "', '" + lieu + "', '" + date + "','"+heure+"','"+sage+"')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id,nom,prenom,mere,pere,infirmier, medecin,lieu, date,heure,sage});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimer() {
        int selectedRow = naissanceTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) naissanceTable.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM naisssance WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une consultation à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifier() {
        int selectedRow = naissanceTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) naissanceTable.getValueAt(selectedRow, 0);
            String nom = nomField.getText();
            String prenom = prenomField.getText();
            String mere = mereField.getText();
            String pere = pereField.getText();
            String infirmier = (String) infirmierComboBox.getSelectedItem();
            String medecin = (String) medecinComboBox.getSelectedItem();
            String lieu = lieuField.getText();
            String date = dateField.getText();
            String heure = heureField.getText();
            String sage = sageField.getText();

            if (!nom.isEmpty() &&!prenom.isEmpty() && !mere.isEmpty() &&  !pere.isEmpty()&&
            		!infirmier.isEmpty() &&!medecin.isEmpty() && !lieu.isEmpty() && !date.isEmpty() &&!heure.isEmpty() &&!sage.isEmpty()) {
                 try {
                    String query = "UPDATE naissance SET nom = '" + nom + "',prenom= '"+prenom+"',mere= '"+mere+"',pere='"+pere+"',infirmier='"+infirmier+"' , medecin = '" + medecin + "', lieu = '"
                            + lieu + "', date = '" + date + "',heure = '"+heure+"',sage = '"+sage+"' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                    naissanceTable.setValueAt(nom, selectedRow, 1);
                    naissanceTable.setValueAt(prenom, selectedRow, 2);
                    naissanceTable.setValueAt(mere, selectedRow, 3);
                    naissanceTable.setValueAt(pere, selectedRow, 4);
                    naissanceTable.setValueAt(infirmier, selectedRow, 5);
                    naissanceTable.setValueAt(medecin, selectedRow, 6);
                    naissanceTable.setValueAt(lieu, selectedRow, 7);
                    naissanceTable.setValueAt(date, selectedRow, 8);
                    naissanceTable.setValueAt(heure, selectedRow, 9);
                    naissanceTable.setValueAt(sage, selectedRow, 10);
                    
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une consultation à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        nomField.setText("");
        prenomField.setText("");
        mereField.setText("");
        pereField.setText("");
        infirmierComboBox.setSelectedIndex(0);
        medecinComboBox.setSelectedIndex(0);
        lieuField.setText("");
        dateField.setText("");
        heureField.setText("");
        sageField.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrer();
        } else if (e.getSource() == supprimerButton) {
            supprimer();
        } else if (e.getSource() == modifierButton) {
            modifier();
        } else if (e.getSource() == retour) {
           retour();
        }
    }

    private void retour() {
		// TODO Auto-generated method stub
    	Autres au = new Autres();
    	au.setVisible(true);
		
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	Naissance n=   new Naissance();
            	n.setExtendedState(MAXIMIZED_BOTH);
            }
        });
    }
}