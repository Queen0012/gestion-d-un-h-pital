package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class Reservation extends JFrame implements ActionListener {
    private JTextField idField, patientField,dateField, debutField,dureeField;
    private JComboBox<String> medecinComboBox,infirmier1combox,infirmier2combox,infirmier3combox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable operationTable;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public Reservation() {
        // Initialisation de la fenêtre
        setTitle("Réservation d'une opération");
      
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
        patientField = new JTextField(10);
        medecinComboBox = new JComboBox<>();
        dureeField = new JTextField(10);
        dateField = new JTextField(10);
        debutField = new JTextField(10);
        infirmier1combox = new JComboBox<>();
        infirmier2combox = new JComboBox<>();
        infirmier3combox  = new JComboBox<>();

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
        retour = new JButton("retour");

        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
        retour.addActionListener(this);

        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(6, 2));
        inputPanel.add(new JLabel("ID_opération"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Médecin"));
        inputPanel.add(medecinComboBox);
        inputPanel.add(new JLabel("Patient"));
        inputPanel.add(patientField);
        inputPanel.add(new JLabel("duree"));
        inputPanel.add(dureeField);
        inputPanel.add(new JLabel("date"));
        inputPanel.add(dateField);
        inputPanel.add(new JLabel("Debut"));
        inputPanel.add(debutField);
        inputPanel.add(new JLabel("infirmier circulant"));
        inputPanel.add(infirmier1combox);
        inputPanel.add(new JLabel("infirmier instrumentiste"));
        inputPanel.add(infirmier2combox);
        inputPanel.add(new JLabel("infirmier anesthesiste"));
        inputPanel.add(infirmier3combox);

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);

        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
        loadinfirmier();
        loadMedecins();

        // Chargement des consultations dans le tableau
        loadConsultations();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadinfirmier() {
        try {
            String query = "SELECT nom FROM infirmier";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom = resultSet.getString("nom");
               infirmier1combox.addItem(nom);
              infirmier2combox.addItem(nom);
               infirmier3combox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadMedecins() {
        try {
            String query = "SELECT nom FROM medecin";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom =resultSet.getString("nom");
                medecinComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadConsultations() {
        try {
            String query = "SELECT * FROM operation";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID_opération");
            tableModel.addColumn("Médecin");
            tableModel.addColumn("Patient");
            tableModel.addColumn("duree");
            tableModel.addColumn("date");
            tableModel.addColumn("Debut");
            tableModel.addColumn("infirmier circulant");
            tableModel.addColumn("infirmier instrumentiste");
            tableModel.addColumn("infirmier anesthesiste");

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String medecin = resultSet.getString("medecin");
                String patient = resultSet.getString("patient");
                String duree = resultSet.getString("duree");
                String date = resultSet.getString("date");
                String debut = resultSet.getString("debut");
                String infirmier1 = resultSet.getString("infirmier1");
                String infirmier2 = resultSet.getString("infirmier2");
                String infirmier3 = resultSet.getString("infirmier3");

                tableModel.addRow(new Object[]{id,medecin,patient,duree,date,debut,infirmier1,infirmier2,infirmier3});
            }

            // Création du tableau avec le modèle de tableau
            operationTable = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(operationTable);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
        String id = idField.getText();
        String medecin = (String) medecinComboBox.getSelectedItem();
        String patient =patientField.getText();
        String duree =dureeField.getText();
        String date = dateField.getText();
        String debut = debutField.getText();
        String infirmier1 = (String) infirmier1combox.getSelectedItem();
        String infirmier2 = (String) infirmier2combox.getSelectedItem();
        String infirmier3 = (String) infirmier3combox.getSelectedItem();

        if (!id.isEmpty() && !patient.isEmpty() && !medecin.isEmpty()
                && !duree.isEmpty()  && !debut.isEmpty() && !date.isEmpty()&& !infirmier1.isEmpty()&& !infirmier2.isEmpty()&& !infirmier3.isEmpty()) {
            try {
                String query = "INSERT INTO operation (id,medecin,patient,duree,date,debut,infirmier1,infirmier2,infirmier3) " +
                        "VALUES (" + id + ", '" + medecin + "', '" + patient + "', '" + duree + "','"+date+"', '" + debut + "','"+infirmier1+"','"+infirmier2+"','"+infirmier3+"')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id,  medecin,patient, duree,date, debut,infirmier1,infirmier2,infirmier3});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimer() {
        int selectedRow =operationTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) operationTable.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM operation WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifier() {
        int selectedRow = operationTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) operationTable.getValueAt(selectedRow, 0);
            String medecin = (String) medecinComboBox.getSelectedItem();
            String patient =patientField.getText();
            String duree =dureeField.getText();
            String date = dateField.getText();
            String debut = debutField.getText();
            String infirmier1 = (String) infirmier1combox.getSelectedItem();
            String infirmier2 = (String) infirmier2combox.getSelectedItem();
            String infirmier3 = (String) infirmier3combox.getSelectedItem();

            if (!patient.isEmpty() && !duree.isEmpty()&& !date.isEmpty()&& !debut.isEmpty()&& !infirmier1.isEmpty()&& !infirmier2.isEmpty()&& !infirmier3.isEmpty()) {
                try {
                    String query = "UPDATE operation SET medecin = '" + medecin + "', patient = '" +patient + "', duree = '"
                            + duree + "',date = '"+date+"', debut = '" + debut + "',infirmier1='"+infirmier1+"',infirmier2='"+infirmier2+"',infirmier3='"+infirmier3+"' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                    operationTable.setValueAt(medecin, selectedRow, 1);
                    operationTable.setValueAt(patient, selectedRow, 2);
                    operationTable.setValueAt(duree, selectedRow, 3);
                    operationTable.setValueAt(date, selectedRow, 4);
                    operationTable.setValueAt(debut, selectedRow, 5);
                    operationTable.setValueAt(infirmier1, selectedRow, 6);
                    operationTable.setValueAt(infirmier2, selectedRow, 7);
                    operationTable.setValueAt(infirmier3, selectedRow, 8);
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        medecinComboBox.setSelectedIndex(0);      
        patientField.setText("");
       dureeField.setText("");
        dateField.setText("");
        debutField.setText("");
        infirmier1combox.setSelectedIndex(0); 
        infirmier2combox.setSelectedIndex(0); 
        infirmier3combox.setSelectedIndex(0); 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrer();
        } else if (e.getSource() == supprimerButton) {
            supprimer();
        } else if (e.getSource() == modifierButton) {
            modifier();
        } else if (e.getSource() == retour) {
            retour();
        }
    }

    private void retour() {
		// TODO Auto-generated method stub
    	operation op = new operation();
    	op.setVisible(true);
		
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	Reservation ab =  new Reservation();
            	ab.setExtendedState(MAXIMIZED_BOTH);
            	ab.setVisible(true);
            }
        });
    }
}