package employer1234;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Autres extends JFrame {
    public Autres() {
        setTitle("A propos de :");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        
        // Création des boutons
        JButton b0 = new JButton("Stagiaires");
        JButton b1 = new JButton("Naissance");
        JButton b2 = new JButton("Décès");
        JButton b3 = new JButton("ASH");
        JButton b4 = new JButton("Vaccination");

        JButton retour = new JButton("retour");
        // Création de l'image au centre de l'interface
       ImageIcon image = new ImageIcon("images/tor.jpg"); 
       JLabel label = new JLabel(image);
        
        // Création du layout
        setLayout(new BorderLayout());
        
        JPanel boutonsPanel = new JPanel(new GridLayout(4,1));
        
        JPanel southpanel = new JPanel();
        boutonsPanel.add(b0);
        boutonsPanel.add(b1);
        boutonsPanel.add(b2);
        boutonsPanel.add(b3);
    
        southpanel.add(retour);
        add(boutonsPanel, BorderLayout.EAST);

        add(label, BorderLayout.CENTER);
        add(southpanel, BorderLayout.SOUTH);

        // Configuration des actions des boutons
        b0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Stagaires sta = new Stagaires();
                sta.setVisible(true);
            }
        });
        
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	Naissance n= new Naissance();
            	n.setExtendedState(MAXIMIZED_BOTH);
            	n.setVisible(true);
            }
        });
        
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               Deces de = new Deces();
           	de.setExtendedState(MAXIMIZED_BOTH);
               de.setVisible(true);
            }
        });
        
        b3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                entretien en = new entretien();
            	en.setExtendedState(MAXIMIZED_BOTH);
                en.setVisible(true);
            }
        });

        retour.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              InterfaceUtilisateur gv= new  InterfaceUtilisateur();
              gv.setExtendedState(MAXIMIZED_BOTH);
               gv.setVisible(true);
            }
        });
        
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                Autres fenetre = new Autres();
                fenetre.setVisible(true);
            }
        });
    }
}
