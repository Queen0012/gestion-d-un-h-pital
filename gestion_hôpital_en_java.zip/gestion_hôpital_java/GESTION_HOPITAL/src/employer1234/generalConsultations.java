package employer1234;
import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class generalConsultations extends JFrame {

    public generalConsultations() {
        setTitle("Consultation générale");
       setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Création des boutons à gauche
        JPanel buttonPanel = new JPanel(new GridLayout(3,1));

        JPanel southPanel = new JPanel();
   
        JButton button1 = new JButton("consultation");
        JButton button2 = new JButton("examen");
        JButton button3 = new JButton("vaccination");

        JButton button4 = new JButton("retour");
        southPanel.add(button4);
        
        

        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        
        // Ajout des boutons à gauche
        mainPanel.add(buttonPanel, BorderLayout.EAST);
        mainPanel.add(southPanel, BorderLayout.SOUTH);
    

    JLabel imageLabel = new JLabel(new ImageIcon("images/cons.jpg")); 
      add(imageLabel, BorderLayout.CENTER); 
      mainPanel.add(imageLabel, BorderLayout.CENTER);

        button1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                GestionDeConsultations gc =   new GestionDeConsultations(); 
             gc.setExtendedState(MAXIMIZED_BOTH);
                gc.setVisible(true);
            }
        });

        button2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                dispose();
                Patient_maladie pm = new Patient_maladie();
               pm.setVisible(true);
            }
        });

        button3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
               GestionVaccination gv= new GestionVaccination();
              gv.setExtendedState(MAXIMIZED_BOTH);
               gv.setVisible(true);
             
            }
        });
        
        button4.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
              InterfaceUtilisateur gv= new  InterfaceUtilisateur();
              gv.setExtendedState(MAXIMIZED_BOTH);
               gv.setVisible(true);
          
            }
        });
        
    add(mainPanel);
    }
    public static void main(String[] args) {
		// TODO Auto-generated method stub
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				generalConsultations in	= new generalConsultations();
				in.setVisible(true);
			}
		});
		

	}

}