package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class RendezVousManager extends JFrame implements ActionListener {
    private JTextField idField,dateField,heureField;
    private JComboBox<String> patientComboBox, medecinComboBox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable rvTable;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public RendezVousManager() {
        // Initialisation de la fenêtre
        setTitle("Gestion des rendez-vous");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
     
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
        dateField = new JTextField(10);
        heureField = new JTextField(10);
        patientComboBox = new JComboBox<>();
        medecinComboBox = new JComboBox<>();
      ;

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
        retour = new JButton("retour");

        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
        retour.addActionListener(this);

        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(5, 1));
        inputPanel.add(new JLabel("ID"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Patient"));
        inputPanel.add(patientComboBox);
        inputPanel.add(new JLabel("Médecin"));
        inputPanel.add(medecinComboBox);
        inputPanel.add(new JLabel("Date"));
        inputPanel.add(dateField);
        inputPanel.add(new JLabel("Heure"));
        inputPanel.add(heureField);
       

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);

        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
        loadPatients();
        loadMedecins();

        // Chargement des consultations dans le tableau
        loadrv();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadPatients() {
        try {
            String query = "SELECT nom FROM patient";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom = resultSet.getString("nom");
                patientComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadMedecins() {
        try {
            String query = "SELECT nom FROM medecin WHERE salaire ='disponible'";
            resultSet = statement.executeQuery(query);

            while (resultSet.next()) {
                String nom =resultSet.getString("nom");
                medecinComboBox.addItem(nom);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void loadrv() {
        try {
            String query = "SELECT * FROM rendezvous";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID");
            tableModel.addColumn("Patient");
            tableModel.addColumn("Médecin");
            tableModel.addColumn("Date");
            tableModel.addColumn("Heure");

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String patient = resultSet.getString("patient");
                String medecin = resultSet.getString("medecin");
                String date = resultSet.getString("date");
                String heure = resultSet.getString("heure");

                tableModel.addRow(new Object[]{id, patient, medecin,date,heure});
            }

            // Création du tableau avec le modèle de tableau
            rvTable = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(rvTable);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
        String id = idField.getText();
        String patient = (String) patientComboBox.getSelectedItem();
        String medecin = (String) medecinComboBox.getSelectedItem();
        String date = dateField.getText();
        String heure = heureField.getText();

        if (!id.isEmpty() && !patient.isEmpty() && !medecin.isEmpty()  && !date.isEmpty() && !heure.isEmpty()) {
            try {
                String query = "INSERT INTO rendezvous (id, patient, medecin,date,heure) " +
                        "VALUES (" + id + ", '" + patient + "', '" + medecin + "','"+date+"','"+heure+"')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id, patient, medecin,date,heure});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimer() {
        int selectedRow = rvTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) rvTable.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM rendezvous WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un rendez-vous à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifier() {
        int selectedRow = rvTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) rvTable.getValueAt(selectedRow, 0);
            String patient = (String) patientComboBox.getSelectedItem();
            String medecin = (String) medecinComboBox.getSelectedItem();
            String date = dateField.getText();
            String heure = heureField.getText();
         

            if (!patient.isEmpty() && !medecin.isEmpty()&& !date.isEmpty()&& !heure.isEmpty()) {
                try {
                    String query = "UPDATE rendezvous SET patient = '" + patient + "', medecin = '" + medecin + "',date = '"+date+"',heure= '"+heure+"' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                   rvTable.setValueAt(patient, selectedRow, 1);
                   rvTable.setValueAt(medecin, selectedRow, 2);
                   rvTable.setValueAt(date, selectedRow, 3);
                   rvTable.setValueAt(heure, selectedRow, 4);
                   
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            } else {
                JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un rendez-vous à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
        patientComboBox.setSelectedIndex(0);
        medecinComboBox.setSelectedIndex(0);
        dateField.setText("");
        heureField.setText("");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrer();
        } else if (e.getSource() == supprimerButton) {
            supprimer();
        } else if (e.getSource() == modifierButton) {
            modifier();
        } else if (e.getSource() == retour) {
           retour();
        }
    
}

    private void retour() {
		// TODO Auto-generated method stub
		InterfaceUtilisateur ui = new InterfaceUtilisateur();
		ui.setVisible(true);
    	
    	
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
            	RendezVousManager rv =  new RendezVousManager();
            	rv.setExtendedState(MAXIMIZED_BOTH);
            }
        });
    }
}