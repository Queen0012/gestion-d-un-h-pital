package employer1234;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Occupation extends JFrame {
	JTable tb1,tb2;
	JScrollPane scrl1,scrl2;
	Statement st;
	ResultSet rst;
	Connectage cn=new Connectage();
	JLabel titre,titre2,titre3,lbnum,lbnumlit,lbnom;
	JTextField tfnum,tfnumlit,tfnom;
	JButton btadd,btsupp,btrech,btenrg,retour;
	
	public Occupation(){
		this.setTitle("Occupations de lits");
		this.setSize(920,800);
		this.setLocationRelativeTo(null);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
	
		
		titre=new JLabel("Enregistrement d'une occupation de lit");
		titre.setBounds(40,20,450,30);
		titre.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(titre);
		
		titre2=new JLabel("Nombre de lits disponibles par salle");
		titre2.setBounds(40,240,450,30);
		titre2.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(titre2);
		
		titre3=new JLabel("Liste des lits occupés");
		titre3.setBounds(540,20,450,30);
		titre3.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(titre3);
		
		lbnum=new JLabel("Numéro Salle");
		lbnum.setBounds(33,60,150,25);
		lbnum.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnum);
		
		tfnum=new JTextField();
		tfnum.setBounds(200,60,150,25);
		pn.add(tfnum);
		
		lbnumlit=new JLabel("Numéro lit");
		lbnumlit.setBounds(53,100,150,25);
		lbnumlit.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnumlit);
		
		tfnumlit=new JTextField();
		tfnumlit.setBounds(200,100,150,25);
		pn.add(tfnumlit);
		
		lbnom=new JLabel("Nom patient");
		lbnom.setBounds(53,140,150,25);
		lbnom.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnom);
		
		tfnom=new JTextField();
		tfnom.setBounds(200,140,150,25);
		pn.add(tfnom);
		
		//bouton
		btadd=new JButton("Enregistrer");
		btadd.setBounds(105,200,100,25);
		btadd.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String a=tfnum.getText(),
						b=tfnumlit.getText(),
								c=tfnom.getText();
	
						
 String sql="insert into lit(num_salle,num_lit,nom_patient) values('"+a+"','"+b+"','"+c+"')";
 String sql2="update salle set nombre_lits=nombre_lits-1 where numero_salle='"+a+"'";
 
           try{
        	   st=cn.laconnexion().createStatement();
        	   st.executeUpdate(sql);
        	   st.executeUpdate(sql2);
        	   JOptionPane.showMessageDialog(null,"Ajout r�ussi !");
        	   dispose();
        	   Occupation sl=new  Occupation();
        	   sl.setVisible(true);
           }
           catch(SQLException ex){
        	 JOptionPane.showMessageDialog(null,"Impossible d'ajouter !",null,JOptionPane.ERROR_MESSAGE);  
           }
				
			}
		});
		pn.add(btadd);
		
		btsupp=new JButton("Liberer");
		btsupp.setBounds(235,200,100,25);
		btsupp.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String a=tfnum.getText(),
						b=tfnumlit.getText();
						
						
String sql="delete from lit where num_salle='"+a+"'";
String sql2="update salle set nombre_lits=nombre_lits+1 where numero_salle='"+a+"'";
           try{
        	   st=cn.laconnexion().createStatement();
        	   if(JOptionPane.showConfirmDialog(null,"Voulez-vous supprimer ?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
        		   st.executeUpdate(sql);
        		   st.executeUpdate(sql2);
            	   JOptionPane.showMessageDialog(null,"Suppréssion r�ussie !");
            	   dispose();
            	   Occupation sl=new  Occupation();
            	   sl.setVisible(true);  
        	   }
        	  
           }
           catch(SQLException ex){
        	 JOptionPane.showMessageDialog(null,"Impossible de supprimer !",null,JOptionPane.ERROR_MESSAGE);  
           }
				
			}
		});
		pn.add(btsupp);
		
		retour=new JButton("retour");
		retour.setBounds(490,630,100,25);
		retour.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev){
				inter g = new inter();
				g.setVisible(true);
			
			}
		});
		pn.add(retour);
		
		
		btenrg=new JButton("Enregistrer des nouvelles places");
		btenrg.setBounds(25,500,407,25);
		btenrg.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				Salle sl=new Salle();
				sl.setVisible(true);	
           }
           
		});
		pn.add(btenrg);
		////
		DefaultTableModel df=new DefaultTableModel();
		init();
		df.addColumn("Numéro salle");
		df.addColumn("Nombre de lits disponibles");
		
		tb1.setModel(df);
		pn.add(scrl1);
		
		String sql="select * from salle";
		
	 cn=new Connectage();
		try{
			st=cn.laconnexion().createStatement();
			rst=st.executeQuery(sql);
			while(rst.next()){
		df.addRow(new Object[]{
				rst.getString("numero_salle"),
				rst.getString("nombre_lits")		
		});
			}
		}
		catch(SQLException ex){
			
		}
		///
		////
				DefaultTableModel df2=new DefaultTableModel();
				init2();
				df2.addColumn("Num�ro salle");
				df2.addColumn("Num�ro lit");
				df2.addColumn("Nom patient");
				
				tb2.setModel(df2);
				pn.add(scrl2);
				
				String sql2="select * from lit";
				
			 cn=new Connectage();
				try{
					st=cn.laconnexion().createStatement();
					rst=st.executeQuery(sql2);
					while(rst.next()){
				df2.addRow(new Object[]{
						rst.getString("num_salle"),
						rst.getString("num_lit"),
						rst.getString("nom_patient")
				});
					}
				}
				catch(SQLException ex){
					
				}
				///
		
		
	}
	private void init(){
		tb1=new JTable();
		scrl1=new JScrollPane();
		scrl1.setViewportView(tb1);
		scrl1.setBounds(25,290,410,200);
	}
	
	private void init2(){
		tb2=new JTable();
		scrl2=new JScrollPane();
		scrl2.setViewportView(tb2);
		scrl2.setBounds(460,100,410,500);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Occupation oc=new Occupation();
		oc.setVisible(true);

	}}
			
