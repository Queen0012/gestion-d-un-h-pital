package employer1234;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class equipement extends JFrame implements ActionListener {
    private JTextField idField;
    private JComboBox<String> e1combox,e2combox,e3combox,e4combox,e5combox,e6combox,e7combox,e8combox,e9combox,e10combox;
    private JButton enregistrerButton, supprimerButton, modifierButton,retour;
    private JTable equipementTable;
    private DefaultTableModel tableModel;

    private Connection connection;
    private Statement statement;
    private ResultSet resultSet;

    public equipement() {
        // Initialisation de la fenêtre
        setTitle("Gestion des equipements d'operations");
  
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Création des composants
        idField = new JTextField(10);
     e1combox = new JComboBox<>(new String[]{"null","Table_operation"});
      e2combox= new JComboBox<>(new String[]{"null", " Instruments(chirurgicaux)"});
      e3combox = new JComboBox<>(new String[]{"null", "Dispositifs(cautérisation)"});
      e4combox= new JComboBox<>(new String[]{"null", "Système_anesthésie"});
      e5combox = new JComboBox<>(new String[]{"null", "Éclairage_chirurgical"});
      e6combox= new JComboBox<>(new String[]{"null", "Système_de_surveillance_des_signes_vitaux"});
      e7combox = new JComboBox<>(new String[]{"null", "Système_de_drainage_des_fluides"});
      e8combox= new JComboBox<>(new String[]{"null", "Système_de_suture"});
      e9combox = new JComboBox<>(new String[]{"null", "Dispositifs_de_support_pour_le_patient"});
      e10combox= new JComboBox<>(new String[]{"null", "Dispositifs_de_protection_et_de_stérilisation "});

        enregistrerButton = new JButton("Enregistrer");
        supprimerButton = new JButton("Supprimer");
        modifierButton = new JButton("Modifier");
        retour = new JButton("retour");

        // Ajout des écouteurs d'événements
        enregistrerButton.addActionListener(this);
        supprimerButton.addActionListener(this);
        modifierButton.addActionListener(this);
       retour.addActionListener(this);

        // Création des panneaux pour les champs d'entrée et les boutons
        JPanel inputPanel = new JPanel(new GridLayout(11, 3));
        inputPanel.add(new JLabel("ID"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("equipement 1"));
        inputPanel.add(e1combox);
        inputPanel.add(new JLabel("equipement 2"));
        inputPanel.add(e2combox);
        inputPanel.add(new JLabel("equipement 3"));
        inputPanel.add(e3combox);
        inputPanel.add(new JLabel("equipement 4"));
        inputPanel.add(e4combox);
        inputPanel.add(new JLabel("equipement 5"));
        inputPanel.add(e5combox);
        inputPanel.add(new JLabel("equipement 6"));
        inputPanel.add(e6combox);
        inputPanel.add(new JLabel("equipement 7"));
        inputPanel.add(e7combox);
        inputPanel.add(new JLabel("equipement 8"));
        inputPanel.add(e8combox);
        inputPanel.add(new JLabel("equipement 9"));
        inputPanel.add(e9combox);
        inputPanel.add(new JLabel("equipement 10"));
        inputPanel.add(e10combox);
        

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(enregistrerButton);
        buttonPanel.add(supprimerButton);
        buttonPanel.add(modifierButton);
        buttonPanel.add(retour);
        
        // Ajout des panneaux à la fenêtre
        add(inputPanel, BorderLayout.NORTH);
        add(buttonPanel, BorderLayout.SOUTH);

        pack();
        setVisible(true);

        // Connexion à la base de données
        connectToDatabase();

        // Chargement des données dans les combobox
      

        loadurg();
    }

    private void connectToDatabase() {
        String url = "jdbc:mysql://localhost:3306/dbhospitalier";
        String username = "root";
        String password = "";

        try {
            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    private void loadurg() {
        try {
            String query = "SELECT * FROM equipement";
            resultSet = statement.executeQuery(query);

// Création du modèle de tableau
            tableModel = new DefaultTableModel();
            tableModel.addColumn("ID");
            tableModel.addColumn("equipement1");
            tableModel.addColumn("equipement2");
            tableModel.addColumn("equipement3");
            tableModel.addColumn("equipement4");
            tableModel.addColumn("equipement5");
            tableModel.addColumn("equipement6");
            tableModel.addColumn("equipement7");
            tableModel.addColumn("equipement8");
            tableModel.addColumn("equipement9");
            tableModel.addColumn("equipement10");
        

            // Ajout des données de la base de données au modèle de tableau
            while (resultSet.next()) {
                int id = resultSet.getInt("id");
                String e1 = resultSet.getString("e1");
                String e2 = resultSet.getString("e2");
                String e3 = resultSet.getString("e3");
                String e4 = resultSet.getString("e4");
                String e5 = resultSet.getString("e5");
                String e6 = resultSet.getString("e6");
                String e7 = resultSet.getString("e7");
                String e8 = resultSet.getString("e8");
                String e9 = resultSet.getString("e9");
                String e10 = resultSet.getString("e10");
         
                
                tableModel.addRow(new Object[]{id,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10});
            }

            // Création du tableau avec le modèle de tableau
            equipementTable = new JTable(tableModel);

            // Ajout du tableau à un JScrollPane pour permettre le défilement
            JScrollPane scrollPane = new JScrollPane(equipementTable);
            add(scrollPane, BorderLayout.CENTER);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
    	   String id = idField.getText();
    	   String e1 = (String) e1combox.getSelectedItem();
    	   String e2 = (String) e2combox.getSelectedItem();
    	    String e3 = (String) e3combox.getSelectedItem();
	        String e4 = (String) e4combox.getSelectedItem();
	        String e5 = (String) e5combox.getSelectedItem();
	        String e6 = (String) e6combox.getSelectedItem();  
	        String e7 = (String) e7combox.getSelectedItem();
	        String e8 = (String) e8combox.getSelectedItem();
  	        String e9 = (String) e9combox.getSelectedItem();
	        String e10 = (String) e10combox.getSelectedItem();
  
	        
        
      


        if (!id.isEmpty()) {
            try {
                String query = "INSERT INTO equipement (id,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10) " +
                        "VALUES (" + id + ", '" +e1 + "','"+e2+"','"+e3+"','"+e4+"','"+e5+"','"+e6+"', '" + e7+ "', '" + e8+ "','"+e9+"','"+e10+"')";
                statement.executeUpdate(query);

                // Actualisation du tableau
                tableModel.addRow(new Object[]{id,e1,e2,e3,e4,e5,e6,e7,e8,e9,e10});
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void supprimerConsultation() {
        int selectedRow = equipementTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) equipementTable.getValueAt(selectedRow, 0);

            try {
                String query = "DELETE FROM equipement WHERE id = " + id;
                statement.executeUpdate(query);

                // Suppression de la ligne du tableau
                tableModel.removeRow(selectedRow);
                clearFields();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à supprimer.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void modifier() {
        int selectedRow = equipementTable.getSelectedRow();

        if (selectedRow != -1) {
            int id = (int) equipementTable.getValueAt(selectedRow, 0);
            String e1 = (String) e1combox.getSelectedItem();
     	   String e2 = (String) e2combox.getSelectedItem();
     	    String e3 = (String) e3combox.getSelectedItem();
 	        String e4 = (String) e4combox.getSelectedItem();
 	        String e5 = (String) e5combox.getSelectedItem();
 	        String e6 = (String) e6combox.getSelectedItem();  
 	        String e7 = (String) e7combox.getSelectedItem();
 	        String e8 = (String) e8combox.getSelectedItem();
   	        String e9 = (String) e9combox.getSelectedItem();
 	        String e10 = (String) e10combox.getSelectedItem();
 
           try {
                    String query = "UPDATE equipement SET e1 = '" + e1 + "',e2= '"+e2+"',e3= '"+e3+"',e4='"+e4+"',e5='"+e5+"' , e6 = '" + e6 + "',e7 = '"+e7+"',e8= '"+e8+"',e9='"+e9+"',e10= '"+e10+"' WHERE id = " + id;
                    statement.executeUpdate(query);

// Mise à jour de la ligne du tableau
                    equipementTable.setValueAt(e1, selectedRow, 1);
                    equipementTable.setValueAt(e2, selectedRow, 2);
                    equipementTable.setValueAt(e3, selectedRow, 3);
                    equipementTable.setValueAt(e4, selectedRow, 4);
                    equipementTable.setValueAt(e5, selectedRow, 5);
                    equipementTable.setValueAt(e6, selectedRow, 6);
                    equipementTable.setValueAt(e7, selectedRow, 7);
                    equipementTable.setValueAt(e8, selectedRow, 8);
                    equipementTable.setValueAt(e9, selectedRow, 9);
                    equipementTable.setValueAt(e10, selectedRow, 10);
                 
                    clearFields();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            
        } else {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne à modifier.", "Erreur", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        idField.setText("");
       e1combox.setSelectedIndex(0);
       e2combox.setSelectedIndex(0);
       e3combox.setSelectedIndex(0);
       e4combox.setSelectedIndex(0);
       e5combox.setSelectedIndex(0);
       e6combox.setSelectedIndex(0);
       e7combox.setSelectedIndex(0);
       e8combox.setSelectedIndex(0);
       e9combox.setSelectedIndex(0);
       e10combox.setSelectedIndex(0);
 
 
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == enregistrerButton) {
            enregistrer();
        } else if (e.getSource() == supprimerButton) {
            supprimerConsultation();
        } else if (e.getSource() == modifierButton) {
            modifier();
        }else if (e.getSource() == retour) {
            retour();
        }
    }

    private void retour() {
		// TODO Auto-generated method stub
		operation e =new   operation();
		e.setVisible(true);
	}

	public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
               equipement e =  new equipement();
               e.setExtendedState(JFrame.MAXIMIZED_BOTH);
               e.setVisible(true);
            }
        });
    }
}