package employer1234;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class entretien extends JFrame {

    private JTextField idField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField ageField;
    private JComboBox<String> genreComboBox;
    private JTextField debutField;
    private JTextField finField;
    private JTextField horaireField;
    private JTextField salaireField;
    private JButton enregistrerButton,retour;
    private JButton supprimerButton;
    private JButton modifierButton;
    private JTable agentsTable;

    private Connection connection;
    private Statement statement;

    public entretien() {
        setTitle("Gestion des agents d'entretien");
        setSize(800, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        connectToDatabase();
        createTable();
        refreshTableData();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(9, 2));
        formPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        formPanel.add(idField);
        formPanel.add(new JLabel("Nom:"));
        nomField = new JTextField();
        formPanel.add(nomField);
        formPanel.add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        formPanel.add(prenomField);
        formPanel.add(new JLabel("Âge:"));
        ageField = new JTextField();
        formPanel.add(ageField);
        formPanel.add(new JLabel("Genre:"));
        genreComboBox = new JComboBox<>(new String[]{"Féminin", "Masculin"});
        formPanel.add(genreComboBox);
        formPanel.add(new JLabel("Début (heure):"));
        debutField = new JTextField();
        formPanel.add(debutField);
        formPanel.add(new JLabel("Fin (heure):"));
        finField = new JTextField();
        formPanel.add(finField);
        formPanel.add(new JLabel("Horaire (par jour):"));
        horaireField = new JTextField();
        formPanel.add(horaireField);
        formPanel.add(new JLabel("Salaire:"));
        salaireField = new JTextField();
        formPanel.add(salaireField);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
          
        
        enregistrerButton = new JButton("Enregistrer");
        enregistrerButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                enregistrerAgent();
            }
        });
        buttonPanel.add(enregistrerButton);

        supprimerButton = new JButton("Supprimer");
        supprimerButton.addActionListener(new ActionListener() {
          
            public void actionPerformed(ActionEvent e) {
                supprimerAgent();
            }
        });
        buttonPanel.add(supprimerButton);

        modifierButton = new JButton("Modifier");
        modifierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifierAgent();
            }
        });
        buttonPanel.add(modifierButton);
        
        
        retour = new JButton("retour");
          retour.addActionListener(new ActionListener() {
           
              public void actionPerformed(ActionEvent e) {
               Autres au =   new Autres();
               au.setVisible(true);
              }
          });
          buttonPanel.add(retour);  
        

        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        agentsTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(agentsTable);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

private void connectToDatabase() {
        try {
            String url = "jdbc:mysql://localhost:3306/dbhospitalier";
            String username = "root";
            String password = "";

            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS entretien (" +
                "id INT PRIMARY KEY," +
                "nom VARCHAR(50)," +
                "prenom VARCHAR(50)," +
                "age INT," +
                "genre VARCHAR(10)," +
                "debut VARCHAR(10)," +
                "fin VARCHAR(10)," +
                "horaire VARCHAR(10)," +
                "salaire DOUBLE" +
                ")";

        try {
            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrerAgent() {
        String id = idField.getText();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String genre = (String) genreComboBox.getSelectedItem();
        String debut = debutField.getText();
        String fin = finField.getText();
        String horaire = horaireField.getText();
        String salaire = salaireField.getText();

        if (id.isEmpty() ||nom.isEmpty() ||prenom.isEmpty()|| age.isEmpty() ||debut.isEmpty() ||
                fin.isEmpty() || horaire.isEmpty() ||salaire.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }

        String insertQuery = "INSERT INTO entretien (id, nom, prenom, age, genre, debut, fin, horaire, salaire) " +
                "VALUES (" + id + ", '" + nom + "', '" + prenom + "', " + age + ", '" + genre + "', '" +
                debut + "', '" + fin + "', '" + horaire + "', " + salaire + ")";

        try {
            statement.executeUpdate(insertQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void supprimerAgent() {
        int selectedRow = agentsTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un agent.");
            return;
        }

        String id = agentsTable.getValueAt(selectedRow, 0).toString();
        String deleteQuery = "DELETE FROM entretien WHERE id = " + id;

        try {
            statement.executeUpdate(deleteQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifierAgent() {
        int selectedRow = agentsTable.getSelectedRow();
       
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner un agent.");
            return;
        }

        String id = agentsTable.getValueAt(selectedRow, 0).toString();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String genre = (String) genreComboBox.getSelectedItem();
        String debut = debutField.getText();
        String fin = finField.getText();
        String horaire = horaireField.getText();
        String salaire = salaireField.getText();

        if (nom.isEmpty() || prenom.isEmpty() || age.isEmpty() || debut.isEmpty() ||
                fin.isEmpty() || horaire.isEmpty() || salaire.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }
String updateQuery = "UPDATE entretien SET nom = '" + nom + "', prenom = '" + prenom +
                "', age = " + age + ", genre = '" + genre + "', debut = '" + debut + "', fin = '" + fin +
                "', horaire = '" + horaire + "', salaire = " + salaire + " WHERE id = " + id;

        try {
            statement.executeUpdate(updateQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTableData() {
        String selectQuery = "SELECT * FROM entretien";

        try {
            ResultSet resultSet = statement.executeQuery(selectQuery);
            agentsTable.setModel(buildTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        nomField.setText("");
        prenomField.setText("");
        ageField.setText("");
        genreComboBox.setSelectedIndex(0);
        debutField.setText("");
        finField.setText("");
        horaireField.setText("");
        salaireField.setText("");
    }

    private static DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        // Table data
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
           
            public void run() {
                entretien agentEntretienGUI = new entretien();
                agentEntretienGUI.setExtendedState(MAXIMIZED_BOTH);
                agentEntretienGUI.setVisible(true);
            }
        });
    }
}
