package employer1234;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;


public class InterfaceUtilisateur extends JFrame {
    private JButton[] boutonsGauche;
    private JButton[] boutonsDroite;

    public InterfaceUtilisateur() {
        super("Gestion d'hopital");
  

        // Création des boutons à gauche avec des noms
        JPanel panelGauche = new JPanel();
     
       
        
        panelGauche.setLayout(new GridLayout(4, 1));
        boutonsGauche = new JButton[4];
        boutonsGauche[0] = new JButton("Médecin");
        boutonsGauche[1] = new JButton("Patient");
        boutonsGauche[2] = new JButton("Administrateur");
        boutonsGauche[3] = new JButton("Urgence");
        for (JButton bouton : boutonsGauche) {
            bouton.addActionListener(new ActionListener() {
                @Override
               
                public void actionPerformed(ActionEvent e) {
                    if (bouton.getText().equals("Médecin")) {
                		MyinterfaceDoctor myinterfaceDoctor = new MyinterfaceDoctor();
        				myinterfaceDoctor.setVisible(true);
                    } else if (bouton.getText().equals("Patient")) {
                		inter myinter = new inter();
        				myinter.setVisible(true);
                    } else if (bouton.getText().equals("Administrateur")) {
                    	Admin admin = new Admin();
                        admin.setVisible(true);
                    }
                    else if (bouton.getText().equals("Urgence")) {
                    	Urgence adm = new Urgence();
                    	adm.setVisible(true);
                    
                    }
                }
            });
            panelGauche.add(bouton);
        }

        // Création des boutons à droite avec des noms
        JPanel panelDroite = new JPanel();
        panelDroite.setLayout(new GridLayout(4, 1));
        boutonsDroite = new JButton[4];
        boutonsDroite[0] = new JButton("RV");
        boutonsDroite[1] = new JButton("Consultation générale");
        boutonsDroite[2] = new JButton("Infirmier");
        boutonsDroite[3] = new JButton("Autres");
        for (JButton bouton : boutonsDroite) {
            bouton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                  
                    if (bouton.getText().equals("RV")) {
                    	RendezVousManager rv = new RendezVousManager();
                    	rv.setExtendedState(MAXIMIZED_BOTH);
                    	rv.setVisible(true);
                    	 
                    } else if (bouton.getText().equals("Consultation générale")) {
                    	generalConsultations et =  new  generalConsultations();
                    	et.setVisible(true);
                    } else if (bouton.getText().equals("Infirmier")) {
                    	GestionInfirmiers g = new GestionInfirmiers();
                    	g.setExtendedState(MAXIMIZED_BOTH);
                    	g.setVisible(true);
                    }
                    else if (bouton.getText().equals("Autres")) {
                    	Autres gm = new Autres();
                    	gm.setExtendedState(MAXIMIZED_BOTH);
                    	gm.setVisible(true);
                    }
                }
            });
            panelDroite.add(bouton);
        }

        // Création du message "Bienvenue" en haut de l'interface
        JLabel labelBienvenue = new JLabel("Bienvenue", SwingConstants.CENTER);
        labelBienvenue.setFont(new Font("Arial", Font.BOLD, 20));

        // Insertion de l'image au centre
        ImageIcon image = new ImageIcon("images/hosp.jpg");
      
        JLabel labelImage = new JLabel(image);
        labelImage.setHorizontalAlignment(JLabel.CENTER);

        // Configuration de la fenêtre
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(panelGauche, BorderLayout.WEST);
        contentPane.add(panelDroite, BorderLayout.EAST);
     
        contentPane.add(labelBienvenue, BorderLayout.NORTH);
        contentPane.add(labelImage, BorderLayout.CENTER);
        setContentPane(contentPane);
    	setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new InterfaceUtilisateur();
            }
        });
    }
}