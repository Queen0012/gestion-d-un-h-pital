package employer1234;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class Urgence extends JFrame {

    private JTextField idField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField ageField;
    private JComboBox<String> genreComboBox;
    private JComboBox<String> groupesanguinComboBox;
    private JTextField antecedentsField;
 
  
    private JButton enregistrerButton,suite;
    private JButton supprimerButton;
    private JButton modifierButton;

    private JTable urgenceTable;

    private Connection connection;
    private Statement statement;

    public Urgence() {
        setTitle("Gestion des urgences");
       setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        connectToDatabase();
        createTable();
        refreshTableData();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(7, 2));
        formPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        formPanel.add(idField);
        formPanel.add(new JLabel("Nom:"));
        nomField = new JTextField();
        formPanel.add(nomField);
        formPanel.add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        formPanel.add(prenomField);
        formPanel.add(new JLabel("Âge:"));
        ageField = new JTextField();
        formPanel.add(ageField);
        formPanel.add(new JLabel("Genre:"));
        genreComboBox = new JComboBox<>(new String[]{"Féminin", "Masculin"});
        formPanel.add(genreComboBox);
        formPanel.add(new JLabel("Groupe sanguin:"));
        groupesanguinComboBox = new JComboBox<>(new String[]{"A+", "A-", "O+", "O-", "B+", "B-", "AB+", "AB-"});
        formPanel.add(groupesanguinComboBox);
        formPanel.add(new JLabel("Antécédents Médicaux:"));
        antecedentsField = new JTextField();
        formPanel.add(antecedentsField);
   
        

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        enregistrerButton = new JButton("Enregistrer");
        enregistrerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enregistrer();
            }
        });
        buttonPanel.add(enregistrerButton);

        supprimerButton = new JButton("Supprimer");
        supprimerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                supprimer();
            }
        });
        buttonPanel.add(supprimerButton);

        modifierButton = new JButton("Modifier");
        modifierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifier();
            }
        });
        buttonPanel.add(modifierButton);
        suite = new JButton("suite");
        suite.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               urgence2 iu = new urgence2();
               iu.setExtendedState(MAXIMIZED_BOTH);
                iu.setVisible(true);
            }
        });

        buttonPanel.add(suite);
        
  
        
        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

        urgenceTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(urgenceTable);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

private void connectToDatabase() {
        try {
            // Remplacez les informations de connexion par celles de votre base de données
            String url = "jdbc:mysql://localhost:3306/dbhospitalier";
            String username = "root";
            String password = "";

            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS urgence (" +
                "id INT PRIMARY KEY," +
                "nom VARCHAR(50)," +
                "prenom VARCHAR(50)," +
                "age INT," +
                "genre VARCHAR(50)," +
                "groupe VARCHAR(50)," +
                "antecedent VARCHAR(50)" +
              
               
                ")";

        try {
            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrer() {
        String id = idField.getText();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String genre = (String) genreComboBox.getSelectedItem();
        String groupe = (String) groupesanguinComboBox.getSelectedItem();
        String antecedent = antecedentsField.getText();

        if (id.isEmpty() ||nom.isEmpty() ||prenom.isEmpty()|| age.isEmpty() ||antecedent.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }

        String insertQuery = "INSERT INTO urgence (id, nom, prenom, age, genre,groupe,antecedent) " +
                "VALUES (" + id + ", '" + nom + "', '" + prenom + "', " + age + ", '" + genre + "', '" + groupe + "','"+antecedent+"')";

        try {
            statement.executeUpdate(insertQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void supprimer() {
        int selectedRow = urgenceTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = urgenceTable.getValueAt(selectedRow, 0).toString();
        String deleteQuery = "DELETE FROM urgence WHERE id = " + id;

        try {
            statement.executeUpdate(deleteQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifier() {
        int selectedRow = urgenceTable.getSelectedRow();
       
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = urgenceTable.getValueAt(selectedRow, 0).toString();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String genre = (String) genreComboBox.getSelectedItem();
        String groupe = (String) groupesanguinComboBox.getSelectedItem();
        String antecedent = antecedentsField.getText();
    


        if (id.isEmpty() ||nom.isEmpty() ||prenom.isEmpty()|| age.isEmpty() ||antecedent.isEmpty()  ) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }
String updateQuery = "UPDATE urgence SET nom = '" + nom + "', prenom = '" + prenom +"', age = " + age + ", genre = '" + genre + "',groupe='"+groupe+"', antecedent = '" + antecedent + "' WHERE id = " + id;

        try {
            statement.executeUpdate(updateQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTableData() {
        String selectQuery = "SELECT * FROM urgence";

        try {
            ResultSet resultSet = statement.executeQuery(selectQuery);
            urgenceTable.setModel(buildTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        nomField.setText("");
        prenomField.setText("");
        ageField.setText("");
        genreComboBox.setSelectedIndex(0);

        groupesanguinComboBox.setSelectedIndex(0);
        antecedentsField.setText("");
       
    }

    private static DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        // Table data
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                Urgence ag = new Urgence();
                ag.setVisible(true);
            }
        });
    }
}
