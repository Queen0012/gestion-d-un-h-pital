package employer1234;

import javax.swing.*;
import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.ImageIcon;


public class GestionVaccination extends JFrame {

    private JButton[] boutonsDroite;

    public GestionVaccination() {
        super("Gestion de vaccination");
  

        JPanel panelDroite = new JPanel();
        JPanel panelsouth = new JPanel();
        
        
        JButton retour = new JButton("retour");
        panelsouth.add(retour);
        
        panelDroite.setLayout(new GridLayout(2, 1));
        boutonsDroite = new JButton[2];
        boutonsDroite[0] = new JButton("Adulte");
        boutonsDroite[1] = new JButton("enfant");
     
        for (JButton bouton : boutonsDroite) {
            bouton.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                  
                    if (bouton.getText().equals("Adulte")) {
                    	vaccination2 et =  new vaccination2();
                    
                    	et.setVisible(true);
                     	et.setExtendedState(MAXIMIZED_BOTH);
                    	 
                    } else if (bouton.getText().equals("enfant")) {
                    	vaccination1 et =  new vaccination1();
                     	et.setExtendedState(MAXIMIZED_BOTH);
                    	et.setVisible(true);
                    } 
                }
            });
            panelDroite.add(bouton);
        }
        
        retour.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		 generalConsultations au = new  generalConsultations();
        		 au.setVisible(true);
        		
        	}
        });
               

        // Insertion de l'image au centre
        ImageIcon image = new ImageIcon("images/just.jpg");
        JLabel labelImage = new JLabel(image);
        labelImage.setHorizontalAlignment(JLabel.CENTER);

        // Configuration de la fenêtre
        JPanel contentPane = new JPanel();
        contentPane.setLayout(new BorderLayout());
        contentPane.add(panelDroite, BorderLayout.EAST);
        contentPane.add(panelsouth, BorderLayout.SOUTH);
        contentPane.add(labelImage, BorderLayout.CENTER);
        setContentPane(contentPane);
    	setExtendedState(JFrame.MAXIMIZED_BOTH);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new GestionVaccination();
            }
        });
    }
}