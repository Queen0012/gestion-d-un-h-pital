package employer1234;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;



public class Patient_maladie extends JFrame {
	Statement st;
	Connectage con=new Connectage();
	ResultSet rst;
	JTable table,table2,table3;
	JScrollPane scroll,scroll2,scroll3;
	JLabel lbtitre1,lbtitre2,lbnom_patient,lbage_patient,lbsexe_patient,lbquartier_patient,lbid_patient,
	lbnom_mal,lbannee,lbmois,lbjour;
	JTextField tfnom_patient,tfage_patient,tfquartier_patient,tfid,tfid2,tfid_patient,tfnom_mal,tfannee,tfmois,tfjour;
	JComboBox combosexe_patient;
	JButton btenrg1,btsupp1,retour,btenrg2,btsupp2,breq;
	public Patient_maladie(){
		this.setTitle("gestion des examens ");
		this.setSize(1000,940);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		
		lbtitre1=new JLabel("Formulaire des patients-examens");
		lbtitre1.setBounds(50,10,800,30);
		lbtitre1.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbtitre1);
		
		lbtitre2=new JLabel("Formulaire d'enregistrement des résultats des examens médicaux");
		lbtitre2.setBounds(50,240,800,30);
		lbtitre2.setFont(new Font("Arial",Font.BOLD,18));
		pn.add(lbtitre2);
		
		//nom patient
				lbnom_patient=new JLabel("Nom");
				lbnom_patient.setBounds(63,50,200,25);
				lbnom_patient.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbnom_patient);
								
				tfnom_patient=new JTextField();
				tfnom_patient.setBounds(150,50,200,25);
				pn.add(tfnom_patient);
		//age patient
				lbage_patient=new JLabel("Age");
				lbage_patient.setBounds(63,80,200,25);
				lbage_patient.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbage_patient);
								
				tfage_patient=new JTextField();
				tfage_patient.setBounds(150,80,100,25);
				pn.add(tfage_patient);
		//sexe patient
				lbsexe_patient=new JLabel("Sexe");
				lbsexe_patient.setBounds(63,110,200,25);
				lbsexe_patient.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbsexe_patient);
				
				combosexe_patient=new JComboBox();
				combosexe_patient.setBounds(150,110,100,25);
				combosexe_patient.addItem("");
				combosexe_patient.addItem("FEMININ");
				combosexe_patient.addItem("MASCULIN");
				pn.add(combosexe_patient);
		//quartier patient
				lbquartier_patient=new JLabel("Quartier");
				lbquartier_patient.setBounds(63,140,200,25);
				lbquartier_patient.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbquartier_patient);
								
				tfquartier_patient=new JTextField();
				tfquartier_patient.setBounds(150,140,100,25);
				pn.add(tfquartier_patient);
	   //tfid
				tfid=new JTextField("ID");
				tfid.setBounds(280,180,70,25);
				pn.add(tfid);
		//tfid2
				tfid2=new JTextField("ID");
				tfid2.setBounds(280,440,70,25);
				pn.add(tfid2);
				
		//identifiant patient
				lbid_patient=new JLabel("Identifiant patient");
				lbid_patient.setBounds(63,280,200,25);
				lbid_patient.setFont(new Font("Arial",Font.BOLD,16));
				pn.add(lbid_patient);
								
				tfid_patient=new JTextField();
				tfid_patient.setBounds(250,280,100,25);
				pn.add(tfid_patient);
				pn.add(tfid);
		//nom maladie
						lbnom_mal=new JLabel("Nom maladie");
						lbnom_mal.setBounds(63,310,200,25);
						lbnom_mal.setFont(new Font("Arial",Font.BOLD,16));
						pn.add(lbnom_mal);
										
						tfnom_mal=new JTextField();
						tfnom_mal.setBounds(250,310,100,25);
						pn.add(tfnom_mal);
		//annee
						lbannee=new JLabel("Année");
						lbannee.setBounds(63,340,200,25);
						lbannee.setFont(new Font("Arial",Font.BOLD,16));
						pn.add(lbannee);
										
						tfannee=new JTextField();
						tfannee.setBounds(250,340,100,25);
						pn.add(tfannee);
			//mois
						lbmois=new JLabel("Mois");
						lbmois.setBounds(63,370,200,25);
						lbmois.setFont(new Font("Arial",Font.BOLD,16));
						pn.add(lbmois);
										
						tfmois=new JTextField();
						tfmois.setBounds(250,370,100,25);
						pn.add(tfmois);
			//jour
						lbjour=new JLabel("Jour");
						lbjour.setBounds(63,400,200,25);
						lbjour.setFont(new Font("Arial",Font.BOLD,16));
						pn.add(lbjour);
										
						tfjour=new JTextField();
						tfjour.setBounds(250,400,100,25);
						pn.add(tfjour);
			//bouton pour acc�der � la fenetre des requetes
						breq=new JButton("BILAN");
						breq.setBounds(600,600,100,25);
						breq.addActionListener(new ActionListener(){
							public void actionPerformed(ActionEvent ev){
								requetes rq=new requetes();
								rq.setVisible(true);
								
							}
							
						});
						pn.add(breq);
		//bouton pour enregistrer les patients
				btenrg1=new JButton("ENREGISTRER");
				btenrg1.setBounds(20,180,120,25);
				btenrg1.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String nom,age,sexe,quartier;
						
						nom=tfnom_patient.getText();
						age=tfage_patient.getText();
						sexe=combosexe_patient.getSelectedItem().toString();
						quartier=tfquartier_patient.getText();
		String rq="insert into tb_patient(nom,age,sexe,quartier,date_exam) values('"+nom+"','"+age+"','"+sexe+"','"+quartier+"',now())";
		
		
		try{
			st=con.laconnexion().createStatement();
			if(!nom.equals("")&&!age.equals("")&&!sexe.equals("")&&!quartier.equals("")){
				st.executeUpdate(rq);
				JOptionPane.showMessageDialog(null,"Enregistrement effectué avec succ�s !",null,JOptionPane.INFORMATION_MESSAGE);	
			}
			else{
				JOptionPane.showMessageDialog(null,"Completez le formulaire!",null,JOptionPane.ERROR_MESSAGE);
			}
			
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		dispose();
		Patient_maladie pm=new Patient_maladie();
		pm.setVisible(true);
		
					}
				}
				);
				pn.add(btenrg1);
	//bouton pour enregistrer les r�sultats des examens m�dicaux des patients
				btenrg2=new JButton("ENREGISTRER");
				btenrg2.setBounds(20,440,120,25);
				btenrg2.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String idpatient,nomal,annee,mois,jour;
						
						idpatient=tfid_patient.getText();
						nomal=tfnom_mal.getText();
						annee=tfannee.getText();
						mois=tfmois.getText();
						jour=tfjour.getText();
		String rq="insert into tb_resultat(id_patient,nom_mal,annee,mois,jour) values('"+idpatient+"','"+nomal+"','"+annee+"','"+mois+"','"+jour+"')";
		
		
		try{
			st=con.laconnexion().createStatement();
			if(!idpatient.equals("")&&!nomal.equals("")&&!annee.equals("")&&!mois.equals("")&&!jour.equals("")){
				st.executeUpdate(rq);
				JOptionPane.showMessageDialog(null,"Enregistrement éffectué avec succès !",null,JOptionPane.INFORMATION_MESSAGE);	
			}
			else{
				JOptionPane.showMessageDialog(null,"Veuillez remplir tous le champ de texte!",null,JOptionPane.ERROR_MESSAGE);
			}
			
		}
		catch(SQLException ex){
	    	JOptionPane.showMessageDialog(null,"Erreur!",null,JOptionPane.ERROR_MESSAGE);	
	    }
		dispose();
		Patient_maladie pm=new Patient_maladie();
		pm.setVisible(true);
		
					}
				}
				);
				pn.add(btenrg2);
				
				retour=new JButton("retour");
				retour.setBounds(450,600,100,25);
				retour.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ev){
						generalConsultations g = new generalConsultations();
						g.setVisible(true);
					
					}
				});
				pn.add(retour);
				
				JButton examen = new JButton("examen");
				examen.setBounds(750,600,100,25);
				examen.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent ev){
						diagnostics g = new diagnostics();
						g.setExtendedState(MAXIMIZED_BOTH);
						g.setVisible(true);
					
					}
				});
				pn.add(examen);
				
				 //bouton pour supprimer les enregistrements de patients dans la base de donn�es
				btsupp1=new JButton("SUPPRIMER");
				btsupp1.setBounds(160,180,110,25);
				btsupp1.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String id;
						id=tfid.getText();
						String rq="delete from tb_patient where idp='"+id+"'";
						
						try{
							st=con.laconnexion().createStatement();
							if(!id.equals("")){
								if(JOptionPane.showConfirmDialog(null, "Voulez-vous supprimez?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
								st.executeUpdate(rq);
								JOptionPane.showMessageDialog(null,"Suppréssion éffectuée avec succés !",null,JOptionPane.INFORMATION_MESSAGE);			
								}
								}
							else{
								JOptionPane.showMessageDialog(null,"Indiquez l'identifiant du patient !",null,JOptionPane.ERROR_MESSAGE);
							}
						}
						 catch(SQLException ex){
						    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
						    }
						dispose();
						Patient_maladie pm=new Patient_maladie();
						pm.setVisible(true);
					}
				});
				pn.add(btsupp1);
				//bouton pour supprimer les r�sultats des examens m�dicaux dans la base de donn�es
				btsupp2=new JButton("SUPPRIMER");
				btsupp2.setBounds(160,440,110,25);
				btsupp2.addActionListener(new ActionListener(){
					public void actionPerformed(ActionEvent ev){
						String id;
						id=tfid2.getText();
						String rq="delete from tb_resultat where id='"+id+"'";
						
						try{
							st=con.laconnexion().createStatement();
							if(!id.equals("")){
								if(JOptionPane.showConfirmDialog(null, "Voulez-vous supprimez?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
								st.executeUpdate(rq);
								JOptionPane.showMessageDialog(null,"Suppréssion éffectuée avec succés !",null,JOptionPane.INFORMATION_MESSAGE);			
								}
								}
							else{
								JOptionPane.showMessageDialog(null,"Indiquez l'identifiant du résultat !",null,JOptionPane.ERROR_MESSAGE);
							}
						}
						 catch(SQLException ex){
						    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
						    }
						dispose();
						Patient_maladie pm=new Patient_maladie();
						pm.setVisible(true);
					}
				});
				pn.add(btsupp2);
				
				//liste des patients enregistr�s
				DefaultTableModel df=new  DefaultTableModel();
				  init();
				  pn.add(scroll);
				 df.addColumn("ID");
				 df.addColumn("Nom");
				 df.addColumn("Age");
				 df.addColumn("Sexe");
				 df.addColumn("Quartier");
				 df.addColumn("Date d'examen");
				 
			
				 table.setModel(df);
				 String req="select * from tb_patient order by idp desc ";
				 try{
					 st=con.laconnexion().createStatement();
					 rst=st.executeQuery(req);
					 while(rst.next()){
						 df.addRow(new Object[]{
		rst.getString("idp"),rst.getString("nom"),rst.getString("age"),rst.getString("sexe"),
		rst.getString("quartier"),rst.getString("date_exam")

								 });
						 
					 }
					 
						 
					 }
					 
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
				 //liste des r�sultats enregistr�s
				 DefaultTableModel df2=new  DefaultTableModel();
				  init2();
				  pn.add(scroll2);
				
				 df2.addColumn("ID_patient");
				 df2.addColumn("Maladie");
				 df2.addColumn("Année");
				 df2.addColumn("Mois");
				 df2.addColumn("Jour");
				 df2.addColumn("ID");
			
				 table2.setModel(df2);
				 String rq="select * from tb_resultat order by id desc ";
				 try{
					 st=con.laconnexion().createStatement();
					 rst=st.executeQuery(rq);
					 while(rst.next()){
						 df2.addRow(new Object[]{
		rst.getString("id_patient"),rst.getString("nom_mal"),rst.getString("annee"),
		rst.getString("mois"),rst.getString("jour"),rst.getString("id")

								 });
						 
					 }	 
					 }
					 
				 catch(SQLException ex){
				    	JOptionPane.showMessageDialog(null,"Erreur !",null,JOptionPane.ERROR_MESSAGE);	
				    }
				 
		
	}
	private void init(){
		table=new JTable();
		scroll=new JScrollPane();
		scroll.setBounds(370,50,600,180);
		scroll.setViewportView(table);
		
	}
	
	private void init2(){
		table2=new JTable();
		scroll2=new JScrollPane();
		scroll2.setBounds(370,300,600,210);
		scroll2.setViewportView(table2);
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Patient_maladie pm=new Patient_maladie();
		pm.setVisible(true);

	}

}
