package employer1234;

import javax.swing.table.DefaultTableModel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;

public class MyinterfaceDoctor extends JFrame {

    private JTextField idField;
    private JTextField nomField;
    private JTextField prenomField;
    private JTextField ageField;
    private JComboBox<String> specialiteComboBox,salaireComboBox;
    private JTextField adresseField;
    private JTextField debutField;
    private JTextField experienceField;
    private JTextField horaireField;
    private JButton enregistrerButton,retour;
    private JButton supprimerButton;
    private JButton modifierButton;
    private JTable doctorTable;

    private Connection connection;
    private Statement statement;

    public MyinterfaceDoctor() {
        setTitle("Gestion des medecins");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initComponents();
        connectToDatabase();
        createTable();
        refreshTableData();
    }

    private void initComponents() {
        JPanel panel = new JPanel(new BorderLayout());

        JPanel formPanel = new JPanel(new GridLayout(10, 2));
        formPanel.add(new JLabel("ID:"));
        idField = new JTextField();
        formPanel.add(idField);
        formPanel.add(new JLabel("Nom:"));
        nomField = new JTextField();
        formPanel.add(nomField);
        formPanel.add(new JLabel("Prénom:"));
        prenomField = new JTextField();
        formPanel.add(prenomField);
        formPanel.add(new JLabel("Âge:"));
        ageField = new JTextField();
        formPanel.add(ageField);
        formPanel.add(new JLabel("Specialité:"));
        specialiteComboBox = new JComboBox<>(new String[]{"Cardiologie", "Pneumologie", "Gastro-entérologie", "Oncologie", "Pédiatrie", "Gynécologie-obstétrique",
                "Neurologie", "Chirurgie générale", "Chirurgie cardiaque", "Chirurgie orthopédique", "Chirurgie plastique", "Dermatologie",
                "Endocrinologie", "Urologie", "Ophtalmologie", "ORL", "Rhumatologie","Medecine generale","echographie","radiographie", "Médecine interne"});
        formPanel.add(specialiteComboBox);
        formPanel.add(new JLabel("adresse"));
        adresseField = new JTextField();
        formPanel.add(adresseField);
        formPanel.add(new JLabel("debut"));
        debutField = new JTextField();
        formPanel.add(debutField);
        formPanel.add(new JLabel("experience:"));
        experienceField = new JTextField();
        formPanel.add(experienceField);
        formPanel.add(new JLabel("Horaire (par jour):"));
        horaireField = new JTextField();
        formPanel.add(horaireField);
        formPanel.add(new JLabel("Salaire:"));
        salaireComboBox = new JComboBox<>(new String[]{"disponible","indisponible"});
        formPanel.add(salaireComboBox);

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
  
        
        
        enregistrerButton = new JButton("Enregistrer");
        enregistrerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                enregistrerAgent();
            }
        });
        buttonPanel.add(enregistrerButton);

        supprimerButton = new JButton("Supprimer");
        supprimerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                supprimerAgent();
            }
        });
        buttonPanel.add(supprimerButton);

        modifierButton = new JButton("Modifier");
        modifierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                modifierAgent();
            }
        });
        buttonPanel.add(modifierButton);
        
        retour = new JButton("retour");
        retour.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                InterfaceUtilisateur iu = new InterfaceUtilisateur();
                iu.setVisible(true);
            }
        });

        buttonPanel.add(retour);
  
        

        panel.add(formPanel, BorderLayout.NORTH);
        panel.add(buttonPanel, BorderLayout.SOUTH);

      doctorTable = new JTable();
        JScrollPane scrollPane = new JScrollPane(doctorTable);

        getContentPane().add(panel, BorderLayout.NORTH);
        getContentPane().add(scrollPane, BorderLayout.CENTER);
    }

private void connectToDatabase() {
        try {
            // Remplacez les informations de connexion par celles de votre base de données
            String url = "jdbc:mysql://localhost:3306/dbhospitalier";
            String username = "root";
            String password = "";

            connection = DriverManager.getConnection(url, username, password);
            statement = connection.createStatement();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void createTable() {
        String createTableQuery = "CREATE TABLE IF NOT EXISTS medecin (" +
                "id INT PRIMARY KEY," +
                "nom VARCHAR(50)," +
                "prenom VARCHAR(50)," +
                "age INT," +
                "specialite VARCHAR(50)," +
                "adresse VARCHAR(50)," +
                "debut VARCHAR(50)," +
                "experience VARCHAR(50)," +
                "horaire VARCHAR(50)," +
                "salaire VARCHAR(50)" +
                ")";

        try {
            statement.executeUpdate(createTableQuery);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void enregistrerAgent() {
        String id = idField.getText();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String specialite = (String) specialiteComboBox.getSelectedItem();
        String adresse = adresseField.getText();
        String debut = debutField.getText();
        String experience = experienceField.getText();
        String horaire = horaireField.getText();
        String salaire =(String) salaireComboBox.getSelectedItem();

        if (id.isEmpty() ||nom.isEmpty() ||prenom.isEmpty()|| age.isEmpty() ||debut.isEmpty() ||
                adresse.isEmpty() || horaire.isEmpty() || experience.isEmpty() ||salaire.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }

        String insertQuery = "INSERT INTO medecin (id, nom, prenom, age, specialite, adresse,debut,experience,horaire,salaire) " +
                "VALUES (" + id + ", '" + nom + "', '" + prenom + "', " + age + ", '" + specialite + "', '"+adresse+"','"+ debut + "', '" + experience+ "', '" + horaire + "', '" + salaire + "')";
             

        try {
            statement.executeUpdate(insertQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void supprimerAgent() {
        int selectedRow = doctorTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = doctorTable.getValueAt(selectedRow, 0).toString();
        String deleteQuery = "DELETE FROM medecin WHERE id = " + id;

        try {
            statement.executeUpdate(deleteQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void modifierAgent() {
        int selectedRow = doctorTable.getSelectedRow();
       
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Veuillez sélectionner une ligne.");
            return;
        }

        String id = doctorTable.getValueAt(selectedRow, 0).toString();
        String nom = nomField.getText();
        String prenom = prenomField.getText();
        String age = ageField.getText();
        String specialite = (String) specialiteComboBox.getSelectedItem();
        String adresse = adresseField.getText();
        String debut = debutField.getText();
        String experience = experienceField.getText();
        String horaire = horaireField.getText();
        String salaire =(String) salaireComboBox.getSelectedItem();


        if (nom.isEmpty() || prenom.isEmpty() || age.isEmpty() || debut.isEmpty() ||
                experience.isEmpty() || horaire.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Veuillez remplir tous les champs.");
            return;
        }
String updateQuery = "UPDATE medecin SET nom = '" + nom + "', prenom = '" + prenom +
                "', age = " + age + ", specialite = '" + specialite + "',adresse='"+adresse+"', debut = '" + debut + "', experience = '" + experience +
                "', horaire = '" + horaire + "', salaire =' " + salaire + "' WHERE id = " + id;

        try {
            statement.executeUpdate(updateQuery);
            refreshTableData();
            clearFields();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void refreshTableData() {
        String selectQuery = "SELECT * FROM medecin";

        try {
            ResultSet resultSet = statement.executeQuery(selectQuery);
            doctorTable.setModel(buildTableModel(resultSet));
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private void clearFields() {
        idField.setText("");
        nomField.setText("");
        prenomField.setText("");
        ageField.setText("");
        specialiteComboBox.setSelectedIndex(0);
        adresseField.setText("");
        debutField.setText("");
        experienceField.setText("");
        horaireField.setText("");
        salaireComboBox.setSelectedIndex(0);
    }

    private static DefaultTableModel buildTableModel(ResultSet resultSet) throws SQLException {
        ResultSetMetaData metaData = resultSet.getMetaData();

        // Column names
        int columnCount = metaData.getColumnCount();
        String[] columnNames = new String[columnCount];
        for (int i = 0; i < columnCount; i++) {
            columnNames[i] = metaData.getColumnName(i + 1);
        }

        // Table data
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);
        while (resultSet.next()) {
            Object[] rowData = new Object[columnCount];
            for (int i = 0; i < columnCount; i++) {
                rowData[i] = resultSet.getObject(i + 1);
            }
            tableModel.addRow(rowData);
        }

        return tableModel;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                MyinterfaceDoctor agentEntretienGUI = new MyinterfaceDoctor();
                agentEntretienGUI.setVisible(true);
            }
        });
    }
}
