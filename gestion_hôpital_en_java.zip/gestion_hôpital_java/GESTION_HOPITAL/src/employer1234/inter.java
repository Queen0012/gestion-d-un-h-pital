package employer1234;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class inter extends JFrame {

    public inter() {
        setTitle("Gestion des patients");
        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        // Création des boutons à gauche
        JPanel buttonPanel = new JPanel(new GridLayout(3,1));
        JPanel buttonPanel1 = new JPanel();

        JButton button1 = new JButton("Formulaire");
        JButton button2 = new JButton("salle");
        JButton button3 = new JButton("operation");
        JButton button4 = new JButton("back");
        buttonPanel.add(button1);
        buttonPanel.add(button2);
        buttonPanel.add(button3);
        buttonPanel1.add(button4);

        // Ajout des boutons à gauche
        mainPanel.add(buttonPanel, BorderLayout.WEST);
        mainPanel.add(buttonPanel1, BorderLayout.SOUTH);
        
        ImageIcon image = new ImageIcon("images/patient.jpg");
        JLabel labelImage = new JLabel(image);
        mainPanel.add(  labelImage, BorderLayout.CENTER);

        // Action lorsqu'on clique sur le bouton 1
        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
        		MyInterfacePatient myinterfacePatient = new MyInterfacePatient();
				myinterfacePatient.setVisible(true);
            
            }
        });
        
        button2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	Salle GestionSalles = new Salle();
            	GestionSalles.setVisible(true);
            
            }
        });
        
        button3.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	operation ope = new operation();
            	ope.setVisible(true);
        		
            }
        });
        button4.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
        		InterfaceUtilisateur my = new InterfaceUtilisateur();
				my.setVisible(true);
            
            }
        });

        // Ajout du panneau principal à la fenêtre
        add(mainPanel);

    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
          
            public void run() {
                new inter().setVisible(true);
            }
        });
    }
}
