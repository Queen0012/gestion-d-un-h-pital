package employer1234;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;


public class Salle extends JFrame {
	JTable tb1;
	JScrollPane scrl1;
	Statement st;
	ResultSet rst;
	Connectage cn=new Connectage();
	JLabel titre,lbnum,lbnombre;
	JTextField tfnum,tfnombre;
	JButton btadd,btsupp,btoccup;
	public Salle(){
		this.setTitle("gestion des salles");
		this.setSize(520,520);
		this.setLocationRelativeTo(null);
		JPanel pn=new JPanel();
		pn.setLayout(null);
		add(pn);
		
		titre=new JLabel("Enregistrement des salles d'hospitalisation");
		titre.setBounds(40,20,450,30);
		titre.setFont(new Font("Arial",Font.BOLD,20));
		pn.add(titre);
		
		lbnum=new JLabel("Numéro de Salle");
		lbnum.setBounds(33,60,150,25);
		lbnum.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnum);
		
		tfnum=new JTextField();
		tfnum.setBounds(200,60,100,25);
		pn.add(tfnum);
		
		lbnombre=new JLabel("Nombre de lits");
		lbnombre.setBounds(53,100,150,25);
		lbnombre.setFont(new Font("Arial",Font.BOLD,16));
		pn.add(lbnombre);
		
		tfnombre=new JTextField();
		tfnombre.setBounds(200,100,100,25);
		pn.add(tfnombre);
		

		//boutons
		btadd=new JButton("Enregistrer");
		btadd.setBounds(105,160,100,25);
		btadd.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String a=tfnum.getText(),
						b=tfnombre.getText();
						
String sql="insert into salle(numero_salle,nombre_lits) values('"+a+"','"+b+"')";
           try{
        	   st=cn.laconnexion().createStatement();
        	   st.executeUpdate(sql);
        	   JOptionPane.showMessageDialog(null,"Ajout r�ussi !");
        	   dispose();
        	   Salle sl=new Salle();
        	   sl.setVisible(true);
           }
           catch(SQLException ex){
        	 JOptionPane.showMessageDialog(null,"Impossible d'ajouter !",null,JOptionPane.ERROR_MESSAGE);  
           }
				
			}
		});
		pn.add(btadd);
		
		btsupp=new JButton("Supprimer");
		btsupp.setBounds(235,160,100,25);
		btsupp.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				String a=tfnum.getText();
						
						
String sql="delete from salle where numero_salle='"+a+"' ";
           try{
        	   st=cn.laconnexion().createStatement();
        	   if(JOptionPane.showConfirmDialog(null,"Voulez-vous supprimer ?",null,JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION){
        		   st.executeUpdate(sql);
            	   JOptionPane.showMessageDialog(null,"Suppréssion réussie !");
            	   dispose();
            	   Salle sl=new Salle();
            	   sl.setVisible(true);  
        	   }
        	  
           }
           catch(SQLException ex){
        	 JOptionPane.showMessageDialog(null,"Impossible de supprimer !",null,JOptionPane.ERROR_MESSAGE);  
           }
				
			}
		});
		pn.add(btsupp);
		
		btoccup=new JButton("Enregistrer les occupations de lits");
		btoccup.setBounds(45,430,410,25);
		btoccup.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				dispose();
				Occupation oc=new Occupation();
				oc.setVisible(true);	
           }
           
		});
		pn.add(btoccup);
		
		////
				DefaultTableModel df=new DefaultTableModel();
				init();
				df.addColumn("Numéro salle");
				df.addColumn("Lits disponibles");
				
				tb1.setModel(df);
				pn.add(scrl1);
				
				String sql="select * from salle";
				
			 cn=new Connectage();
				try{
					st=cn.laconnexion().createStatement();
					rst=st.executeQuery(sql);
					while(rst.next()){
				df.addRow(new Object[]{
						rst.getString("numero_salle"),
						rst.getString("nombre_lits")		
				});
					}
				}
				catch(SQLException ex){
					
				}
				///
	}
	private void init(){
		tb1=new JTable();
		scrl1=new JScrollPane();
		scrl1.setViewportView(tb1);
		scrl1.setBounds(45,210,410,210);
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
     Salle sl=new Salle();
     sl.setVisible(true);
	}

	}

	